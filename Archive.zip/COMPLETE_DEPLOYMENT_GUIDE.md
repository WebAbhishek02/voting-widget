# 🚀 Complete Deployment Master Checklist

Your step-by-step guide to deploy the Voting Widget to GitHub and Hostinger.

---

## Phase 1: Prepare Your Machine (5 minutes)

### Install Git

- [ ] Open Terminal
- [ ] Run: `xcode-select --install`
- [ ] Wait for installation to complete
- [ ] Verify: Run `git --version` (should show version number)

**Guide**: See `GIT_SETUP.md`

### Configure Git

```bash
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
```

- [ ] Run both commands above
- [ ] Replace with your actual name and email

---

## Phase 2: Create GitHub Repository (2 minutes)

### Create GitHub Account

- [ ] Go to [github.com](https://github.com)
- [ ] Click "Sign up"
- [ ] Complete registration
- [ ] Verify your email

### Create New Repository

- [ ] Log in to GitHub
- [ ] Click "+" → "New repository"
- [ ] **Name**: `voting-widget`
- [ ] **Description**: `Production-ready voting widget for restaurants`
- [ ] **Visibility**: Choose **Public** or **Private**
- [ ] **Initialize**: Leave UNCHECKED
- [ ] Click "Create repository"

### Get Repository URL

- [ ] Click green "Code" button
- [ ] Copy the HTTPS URL (should look like: `https://github.com/USERNAME/voting-widget.git`)
- [ ] Save this URL - you'll need it next

---

## Phase 3: Upload to GitHub (5 minutes)

### Initialize Git in Project

```bash
cd /Users/abhishekmishra/Documents/Learning/test-project
git init
git add .
git commit -m "Initial commit: Production-ready voting widget"
```

- [ ] Run all three commands above
- [ ] Wait for commit to complete

### Push to GitHub

Replace `YOUR_USERNAME` with your GitHub username:

```bash
git remote add origin https://github.com/YOUR_USERNAME/voting-widget.git
git branch -M main
git push -u origin main
```

- [ ] Replace `YOUR_USERNAME` with your actual username
- [ ] Run all three commands
- [ ] Enter GitHub username when prompted
- [ ] Enter Personal Access Token as password (see `GIT_SETUP.md` if stuck)
- [ ] Wait for upload to complete

### Verify on GitHub

- [ ] Visit `https://github.com/YOUR_USERNAME/voting-widget`
- [ ] Verify all files are there
- [ ] Click on `/src`, `/public`, `/database` folders to confirm

**Guide**: See `GIT_SETUP.md`

---

## Phase 4: Prepare for Hostinger (5 minutes)

### Create Production Configuration

#### Step 1: Create .env File

In Terminal:

```bash
cd /Users/abhishekmishra/Documents/Learning/test-project
cp .env.example .env
```

- [ ] File `.env` created successfully

#### Step 2: Edit .env (You'll update this after getting database credentials)

```bash
# Will edit after setting up database on Hostinger
```

- [ ] Keep `.env.example` unchanged
- [ ] Use only `.env` for production

### Prepare Upload Files

- [ ] Ensure `.gitignore` is present
- [ ] Ensure `.htaccess` is present
- [ ] Ensure all `/src`, `/public`, `/database` folders exist
- [ ] Do NOT upload: `.git`, `node_modules`, `.env` (yet - you'll update it first)

**Guide**: See `HOSTINGER_SETUP.md`

---

## Phase 5: Set Up Hostinger Account (3 minutes)

### Create Hostinger Account

- [ ] Go to [hostinger.com](https://www.hostinger.com)
- [ ] Click "Get Started"
- [ ] Choose hosting plan (most basic is fine)
- [ ] Complete registration and payment

### Get Hosting Details

- [ ] Wait for confirmation email
- [ ] Log in to [hpanel.hostinger.com](https://hpanel.hostinger.com)
- [ ] Click on your hosting plan
- [ ] Note down:
  - [ ] Your domain name
  - [ ] FTP Host: (usually starts with `ftp.`)
  - [ ] FTP Username
  - [ ] FTP Password

Save these in a safe place!

---

## Phase 6: Download FTP Client (2 minutes)

Choose ONE FTP client and download:

**Option A: Cyberduck (Mac Recommended)**

- [ ] Download from [cyberduck.io](https://cyberduck.io)
- [ ] Install and open

**Option B: FileZilla (Windows/Mac/Linux)**

- [ ] Download from [filezilla-project.org](https://filezilla-project.org)
- [ ] Install and open

**Option C: WinSCP (Windows)**

- [ ] Download from [winscp.net](https://winscp.net)
- [ ] Install and open

---

## Phase 7: Create Database on Hostinger (5 minutes)

### Create New Database

- [ ] In Hostinger control panel → **Databases**
- [ ] Click **"Create Database"** or **"Add New Database"**
- [ ] **Database Name**: `voting_widget`
- [ ] **Database User**: `voting_user` (or your choice)
- [ ] **Database Password**: Create strong password (save this!)
- [ ] Click **"Create"**

### Save Database Credentials

```
DB_HOST: localhost
DB_NAME: voting_widget
DB_USER: voting_user
DB_PASS: YourSecurePassword123
```

- [ ] Save these credentials securely

### Import Database Schema

- [ ] Go to **phpMyAdmin** in Hostinger
- [ ] Select your database from left menu
- [ ] Click **"Import"** tab
- [ ] Click **"Choose File"**
- [ ] Select: `/Users/abhishekmishra/Documents/Learning/test-project/database/schema.sql`
- [ ] Click **"Import"**
- [ ] Verify: You should see 4 tables (admins, widgets, restaurants, votes)

- [ ] ✅ Database ready!

---

## Phase 8: Update Configuration Files (5 minutes)

### Update .env File

Edit `.env` with database credentials:

```
DB_HOST=localhost
DB_USER=voting_user
DB_PASS=YourSecurePassword123
DB_NAME=voting_widget
APP_URL=https://yourdomain.com/voting-widget
APP_ENV=production
```

- [ ] Update with your actual credentials
- [ ] Update with your actual domain
- [ ] Save file

### Update database.php (Optional if using .env)

- [ ] If not using .env, manually edit `src/config/database.php`
- [ ] Update lines 6-10 with database credentials
- [ ] Save file

---

## Phase 9: Connect to Hostinger via FTP (3 minutes)

### Open FTP Client

- [ ] Launch your FTP client (Cyberduck, FileZilla, or WinSCP)

### Connect with Hostinger Credentials

In FTP client, enter:

- **Server/Host**: ftp.yourdomain.com (from Hostinger)
- **Username**: Your FTP username (from Hostinger)
- **Password**: Your FTP password (from Hostinger)
- **Port**: 21 (or 22 for SFTP)

- [ ] Click "Connect"
- [ ] Wait for connection
- [ ] You should see `/public_html` folder

---

## Phase 10: Create Project Folder & Upload (10 minutes)

### Create Folder

- [ ] In FTP client, navigate to `/public_html`
- [ ] Right-click → **"Create Folder"** or **"New Folder"**
- [ ] Name: `voting-widget`
- [ ] Double-click to enter folder

### Upload Files

Inside `/voting-widget` folder, upload these items:

**Folders to upload:**

- [ ] `/src`
- [ ] `/public`
- [ ] `/database`

**Files to upload:**

- [ ] `.htaccess`
- [ ] `.env` (with your credentials)
- [ ] `.gitignore`
- [ ] `README.md`
- [ ] `QUICKSTART.md`
- [ ] `API.md`
- [ ] All other `.md` files

**How to upload:**

- Option A: Drag & drop from left (local) to right (Hostinger) pane
- Option B: Right-click → "Upload"
- Option C: Select all → Upload

**Wait for upload to complete** (you'll see progress bar)

- [ ] All files uploaded successfully

---

## Phase 11: Set File Permissions (3 minutes)

### Via File Manager (Easiest)

- [ ] Go to Hostinger **File Manager** (or use FTP client)
- [ ] Navigate to `/voting-widget`
- [ ] Right-click → **"Change Permissions"** or **"Permissions"**
- [ ] Set to: `755`
- [ ] Apply to all files and folders
- [ ] Right-click `/public/uploads` → **"Change Permissions"** → `755`

- [ ] ✅ Permissions set

---

## Phase 12: Enable SSL Certificate (3 minutes)

### Install SSL

- [ ] Go to Hostinger control panel → **SSL Certificates**
- [ ] Click **"Install Let's Encrypt"** (free)
- [ ] Select your domain
- [ ] Click **"Install"**
- [ ] Wait 5-10 minutes

### Verify HTTPS

- [ ] Visit: `https://yourdomain.com/voting-widget/`
- [ ] You should see the landing page
- [ ] Check for HTTPS lock icon in address bar

- [ ] ✅ SSL working

---

## Phase 13: Test Installation (5 minutes)

### Access Admin Panel

- [ ] Open browser
- [ ] Navigate to: `https://yourdomain.com/voting-widget/public/admin/`
- [ ] You should see login page

### First Login

- [ ] **Username**: `admin`
- [ ] **Password**: `admin123`
- [ ] Click **"Login"**

If this works, your installation is successful! ✅

If not, see troubleshooting in `HOSTINGER_SETUP.md`

### Test Database Connection

- [ ] On dashboard, you should see statistics
- [ ] You should see "Total Widgets: 1" (default widget)
- [ ] If you see these, database is connected ✅

---

## Phase 14: Change Admin Password (2 minutes)

### CRITICAL - Do This Now!

Default credentials are publicly known. Change immediately:

- [ ] Click **"Settings"** (right sidebar)
- [ ] Scroll to **"Change Password"**
- [ ] Enter new strong password
- [ ] Click **"Update Password"**
- [ ] Logout
- [ ] Login with new password to verify

- [ ] ✅ Admin password changed

---

## Phase 15: Create Test Widget (5 minutes)

### Add Widget

- [ ] Click **"Widgets"** in sidebar
- [ ] Click **"Add New Widget"** or **"Create Widget"**
- [ ] **Name**: Test Widget
- [ ] **Theme**: Light
- [ ] **Max Restaurants**: 5
- [ ] **Show Vote Count**: Yes
- [ ] Click **"Create"**
- [ ] Copy the **Widget ID** (you'll need this)

- [ ] ✅ Widget created

### Add Restaurants

- [ ] Click **"Restaurants"** in sidebar
- [ ] Click **"Add New Restaurant"**
- [ ] **Name**: Test Restaurant
- [ ] **Description**: Test description
- [ ] **Image**: Upload an image (JPG/PNG/GIF)
- [ ] Click **"Add Restaurant"**
- [ ] Repeat to add 3-5 test restaurants

- [ ] ✅ Restaurants added

---

## Phase 16: Test Voting (3 minutes)

### Visit Public Page

- [ ] Navigate to: `https://yourdomain.com/voting-widget/public/index.html`
- [ ] You should see the public demo page

### Test Widget

- [ ] Click vote buttons on the widget
- [ ] Vote counts should increase
- [ ] Try voting multiple times (should be rate-limited)

### Verify in Admin

- [ ] Log in to admin panel
- [ ] Click **"Votes"** in sidebar
- [ ] You should see your test votes recorded

- [ ] ✅ Voting works!

---

## Phase 17: Final Security Check (5 minutes)

- [ ] [ ] Default admin password changed (Phase 14)
- [ ] [ ] `.env` file on server (not `.env.example`)
- [ ] [ ] Database user has limited permissions
- [ ] [ ] Uploads directory has proper permissions (755)
- [ ] [ ] `.htaccess` is in place
- [ ] [ ] HTTPS is working (lock icon)
- [ ] [ ] No debug mode enabled
- [ ] [ ] Error logs configured

- [ ] ✅ Security verified

---

## Phase 18: Go Live! (0 minutes)

### You're Done! 🎉

Your voting widget is now live and production-ready!

- [ ] **Admin URL**: `https://yourdomain.com/voting-widget/public/admin/`
- [ ] **Public URL**: `https://yourdomain.com/voting-widget/`
- [ ] **API Endpoint**: `https://yourdomain.com/voting-widget/src/api/`

### Next Steps

1. **Customize**: Add your real restaurants and images
2. **Embed**: Use embed code to add widget to your website
3. **Monitor**: Check admin panel regularly for votes
4. **Maintain**: Keep backups and monitor server logs

---

## Post-Launch Checklist

### Daily

- [ ] Check admin panel for new votes
- [ ] Review any error logs
- [ ] Monitor website performance

### Weekly

- [ ] Review voting statistics
- [ ] Check server resource usage
- [ ] Verify backups completed
- [ ] Test login access

### Monthly

- [ ] Security audit
- [ ] Performance review
- [ ] Database optimization
- [ ] Update documentation

---

## Quick Reference URLs

```
GitHub Repository:
https://github.com/YOUR_USERNAME/voting-widget

Hostinger Control Panel:
https://hpanel.hostinger.com

Admin Panel:
https://yourdomain.com/voting-widget/public/admin/

Public Page:
https://yourdomain.com/voting-widget/

API Endpoint:
https://yourdomain.com/voting-widget/src/api/
```

---

## Documentation References

- **GIT_SETUP.md** - Git installation and GitHub upload
- **HOSTINGER_SETUP.md** - Hostinger deployment guide
- **GITHUB_HOSTINGER_SETUP.md** - Comprehensive deployment guide
- **DEPLOYMENT.md** - Production deployment information
- **README.md** - Complete project documentation
- **API.md** - API endpoint reference

---

## Need Help?

### Troubleshooting

1. Check the relevant `.md` file above
2. Review error logs in Hostinger
3. Check browser console (F12 in browser)
4. Try accessing API directly to test

### Support

- **Hostinger Help**: [support.hostinger.com](https://support.hostinger.com)
- **GitHub Help**: [docs.github.com](https://docs.github.com)
- **PHP Issues**: Check error logs

---

## Statistics

- **Total Files**: 27+
- **Total Code Lines**: 6,000+
- **Deployment Time**: ~1-2 hours (first time)
- **Maintenance Time**: ~10 minutes/week

---

**Congratulations! Your production voting widget is live! 🚀**

---

**Last Updated**: December 18, 2025  
**Version**: 1.0  
**Status**: Production Ready

✅ **ALL SYSTEMS GO** ✅
