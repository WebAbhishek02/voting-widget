# 🔧 Install Git & Push to GitHub - Quick Guide

Your Mac needs Git to upload to GitHub. Follow these simple steps.

---

## Step 1: Install Git on Mac

### Option A: Install Xcode Command Line Tools (Recommended)

Open Terminal and run:

```bash
xcode-select --install
```

A dialog will appear asking to install Xcode Command Line Tools. Click **"Install"** and wait 10-15 minutes.

### Option B: Install Git via Homebrew

If you have Homebrew installed:

```bash
brew install git
```

### Option C: Download Git Directly

Visit [git-scm.com](https://git-scm.com) and download the macOS installer.

---

## Step 2: Verify Git Installation

After installation, run:

```bash
git --version
```

You should see something like: `git version 2.40.0`

---

## Step 3: Configure Git (First Time Only)

Run these commands once:

```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

Replace with your actual name and email.

---

## Step 4: Create GitHub Account (if you don't have one)

1. Go to [github.com](https://github.com)
2. Click **"Sign up"**
3. Follow the steps to create account
4. Verify your email

---

## Step 5: Create Repository on GitHub

1. Log in to GitHub
2. Click **"+"** (top right) → **"New repository"**
3. Fill in:
   - **Repository name**: `voting-widget`
   - **Description**: `Production-ready voting widget for restaurants`
   - **Visibility**: Select **Public** (if you want to share) or **Private**
   - **Initialize repository**: Leave UNCHECKED
4. Click **"Create repository"**

Copy the repository URL you see (looks like: `https://github.com/YOUR_USERNAME/voting-widget.git`)

---

## Step 6: Initialize Git in Your Project

Open Terminal and navigate to your project:

```bash
cd /Users/abhishekmishra/Documents/Learning/test-project
```

Initialize git:

```bash
git init
```

Add all files:

```bash
git add .
```

Create initial commit:

```bash
git commit -m "Initial commit: Production-ready voting widget"
```

---

## Step 7: Connect to GitHub and Push

Replace `YOUR_USERNAME` with your GitHub username, then run:

```bash
git remote add origin https://github.com/YOUR_USERNAME/voting-widget.git
git branch -M main
git push -u origin main
```

You'll be prompted for:

- **Username**: Your GitHub username
- **Password**: Your GitHub password (or personal access token)

**Note**: GitHub no longer accepts passwords. You need a Personal Access Token:

### Create Personal Access Token (if password doesn't work):

1. Go to GitHub Settings → **Developer settings** → **Personal access tokens**
2. Click **"Generate new token"**
3. Name it: `git-push`
4. Select scopes: `repo` (all)
5. Click **"Generate token"**
6. **Copy the token** (you won't see it again!)
7. Use token as password when git asks

---

## Step 8: Verify Upload

1. Go to `https://github.com/YOUR_USERNAME/voting-widget`
2. You should see all your files!
3. Click on folders to verify structure

---

## Troubleshooting

### "fatal: Not a git repository"

Run: `git init` first

### "fatal: origin already exists"

Run:

```bash
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/voting-widget.git
git push -u origin main
```

### "fatal: Permission denied (publickey)"

Use HTTPS instead of SSH:

```bash
git remote set-url origin https://github.com/YOUR_USERNAME/voting-widget.git
```

### "fatal: Authentication failed"

Use Personal Access Token instead of password:

1. Create token at github.com/settings/tokens
2. Use token when prompted for password

---

## Next: Upload to Hostinger

After Git is installed and you've pushed to GitHub, follow the **HOSTINGER_SETUP.md** guide to deploy your application.

---

## Quick Command Reference

```bash
# First time setup
git config --global user.name "Your Name"
git config --global user.email "your@email.com"

# Initialize repository
git init
git add .
git commit -m "Initial commit"

# Connect to GitHub
git remote add origin https://github.com/USERNAME/voting-widget.git
git branch -M main
git push -u origin main

# After making changes
git add .
git commit -m "Your message"
git push
```

---

**Ready to push? You're 2 minutes away! 🚀**
