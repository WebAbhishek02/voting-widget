#!/bin/bash

# GitHub Upload Script for Voting Widget
# This script automates uploading your project to GitHub

set -e  # Exit on error

echo "🚀 Voting Widget - GitHub Upload Script"
echo "========================================"
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git is not installed. Please install Git first:"
    echo "   Visit: https://git-scm.com/download/mac"
    exit 1
fi

# Get GitHub username
read -p "Enter your GitHub username: " github_username

# Get repository name
read -p "Enter repository name (default: voting-widget): " repo_name
repo_name=${repo_name:-voting-widget}

# Get repository visibility
read -p "Make repository Public or Private? (public/private, default: public): " visibility
visibility=${visibility:-public}

echo ""
echo "📋 Configuration:"
echo "   GitHub Username: $github_username"
echo "   Repository Name: $repo_name"
echo "   Visibility: $visibility"
echo ""

# Confirm
read -p "Continue? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Cancelled."
    exit 1
fi

echo ""
echo "🔧 Setting up Git repository..."

# Initialize git (if not already initialized)
if [ ! -d .git ]; then
    git init
    echo "✅ Git repository initialized"
else
    echo "✅ Git repository already exists"
fi

# Add all files
git add .
echo "✅ All files staged"

# Create commit
if git commit -m "Initial commit: Production-ready voting widget application" 2>/dev/null; then
    echo "✅ Initial commit created"
else
    echo "✅ Using existing commits"
fi

# Check if remote exists
if git remote | grep -q origin; then
    git remote remove origin
    echo "✅ Updated remote origin"
else
    echo "✅ Adding remote origin"
fi

# Add GitHub remote
git remote add origin "https://github.com/$github_username/$repo_name.git"
echo "✅ Remote repository configured"

# Rename branch to main (if needed)
if git rev-parse --verify main 2>/dev/null; then
    echo "✅ Using 'main' branch"
else
    git branch -M main
    echo "✅ Renamed branch to 'main'"
fi

echo ""
echo "📤 Ready to push to GitHub!"
echo ""
echo "Next steps:"
echo "1. Visit: https://github.com/new"
echo "2. Enter repository name: $repo_name"
echo "3. Make it $visibility"
echo "4. Click 'Create repository' (don't initialize with README)"
echo "5. Run this command:"
echo ""
echo "   git push -u origin main"
echo ""
echo "Or copy and run the full commands below:"
echo ""
echo "   git push -u origin main"
echo ""
echo "Then verify at: https://github.com/$github_username/$repo_name"
echo ""
echo "🎉 Your repository will be live on GitHub!"
