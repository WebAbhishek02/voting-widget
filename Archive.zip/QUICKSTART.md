# Quick Start Guide

Get up and running in 10 minutes.

## 1. Initial Setup (2 minutes)

### Download Files

```bash
cd /path/to/your/webroot
# Copy all project files here
```

### Create Uploads Directory

```bash
mkdir -p public/uploads
chmod 755 public/uploads
```

## 2. Database Setup (2 minutes)

### Option A: Local/Dev Server

```bash
mysql -u root -p < database/schema.sql
```

### Option B: Shared Hosting (cPanel)

1. Go to **cPanel → Databases → MySQL Databases**
2. Create database: `voting_widget`
3. Create user: `voting_user` with password `StrongPass123`
4. Grant all privileges
5. Import `database/schema.sql` via phpMyAdmin

## 3. Configure Database (2 minutes)

Edit `/src/config/database.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'voting_widget');
define('DB_USER', 'voting_user');
define('DB_PASS', 'StrongPass123');
```

## 4. Access Admin Panel (1 minute)

Navigate to:

```
http://localhost/public/admin/login.php
```

Login with:

- **Username**: `admin`
- **Password**: `admin123`

## 5. Change Default Password (1 minute)

1. Click **Settings** in admin panel
2. Go to **Change Password** section
3. Enter current password: `admin123`
4. Enter new secure password (min 8 chars)
5. Click **Change Password**

## 6. Create First Widget (2 minutes)

1. Click **Widgets** in admin panel
2. Fill in form:
   - **Widget Name**: "My Restaurant Votes"
   - **Theme**: Light
   - **Max Restaurants**: 5
3. Click **Create Widget**

## 7. Add Restaurants (1 minute)

1. Go to **Restaurants** page
2. Fill in form:
   - **Restaurant Name**: "Pizza Palace"
   - **External Link**: "https://pizzapalace.com"
   - **Image**: Upload a restaurant image
3. Click **Add Restaurant**
4. Repeat for 3-5 restaurants

## 8. Get Embed Code

1. Go to **Widgets** page
2. Find your widget card
3. Copy the embed code at bottom of card

## 9. Test on Demo Page

Add to your website HTML:

```html
<script
  src="https://yourdomain.com/public/widget/embed.js"
  data-widget-id="1"
  data-theme="light"
></script>
```

Replace `yourdomain.com` with your actual domain.

## 10. View Results

1. Visit your website where widget is embedded
2. Vote for restaurants
3. Check admin panel → **Votes** to see statistics

---

## Troubleshooting

### Can't connect to database?

- Check credentials in `src/config/database.php`
- Verify MySQL is running
- Test connection: `mysql -u voting_user -p voting_widget`

### Can't upload images?

- Run: `chmod 755 public/uploads`
- Check PHP upload limits in php.ini

### Widget not loading?

- Check browser console (F12)
- Verify widget ID exists
- Verify domain is correct in embed code

### Forgot admin password?

```sql
-- Via MySQL, reset to admin123:
UPDATE admins
SET password_hash = '$2y$12$3.f7l5UHWpL1l.yfCEpf.eW7Vc6.Fb5t0pKL2qLjN8hXVLNyEMx6'
WHERE username = 'admin';
```

---

## Next Steps

- [ ] Change default admin password
- [ ] Add more restaurants
- [ ] Test voting on multiple devices
- [ ] Configure HTTPS
- [ ] Set up database backups
- [ ] Test on production server

## File Structure Reference

```
public/
├── index.html              # Demo page
├── uploads/                # Restaurant images
├── widget/
│   ├── embed.js           # Embed script
│   ├── widget.js          # Main widget
│   └── widget.css         # Styles
└── admin/
    ├── login.php          # Admin login
    ├── index.php          # Dashboard
    ├── restaurants.php    # Manage restaurants
    ├── votes.php          # View votes
    ├── widgets.php        # Manage widgets
    └── settings.php       # Settings

src/
├── config/
│   ├── database.php       # Database config
│   └── security.php       # Security functions
├── api/
│   ├── vote.php          # Vote endpoint
│   └── data.php          # Data endpoint
└── admin/
    └── auth.php          # Authentication

database/
└── schema.sql            # Database schema
```

## Key URLs

| Page            | URL                                       |
| --------------- | ----------------------------------------- |
| Demo            | `http://localhost/public/index.html`      |
| Admin Login     | `http://localhost/public/admin/login.php` |
| Admin Dashboard | `http://localhost/public/admin/index.php` |
| Vote API        | `POST /src/api/vote.php`                  |
| Data API        | `GET /src/api/data.php?widget_id=1`       |

## Admin Panel Navigation

- **Dashboard**: Overview of all statistics
- **Restaurants**: Add, edit, delete restaurants
- **Votes**: View voting statistics, reset votes
- **Widgets**: Create and manage widgets
- **Settings**: Change password, view API info

## Production Deployment

When ready to go live, see `DEPLOYMENT.md` for:

- Server setup
- SSL/HTTPS configuration
- Database backups
- Security hardening
- Performance optimization
- Monitoring setup

---

## Support

1. Check `README.md` for full documentation
2. Review `DEPLOYMENT.md` for production setup
3. See `EMBED_EXAMPLE.html` for embedding examples
4. Check browser console (F12) for JavaScript errors
5. Review PHP error logs for server errors

---

**You're all set!** 🎉

Your voting widget is ready to use. Start embedding it on your website.
