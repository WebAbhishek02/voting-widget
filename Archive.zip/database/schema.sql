-- Voting Widget Database Schema
-- Production-ready MySQL database setup

CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `username` VARCHAR(100) UNIQUE NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `last_login` TIMESTAMP NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  INDEX idx_username (username),
  INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `widgets` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `api_key` VARCHAR(255) UNIQUE NOT NULL,
  `admin_id` INT NOT NULL,
  `theme` ENUM('light', 'dark') DEFAULT 'light',
  `max_restaurants` INT DEFAULT 5,
  `show_vote_count` TINYINT(1) DEFAULT 1,
  `voting_enabled` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_active` TINYINT(1) DEFAULT 1,
  FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE,
  INDEX idx_api_key (api_key),
  INDEX idx_admin_id (admin_id),
  INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `restaurants` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `widget_id` INT NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `image_url` VARCHAR(500),
  `external_link` VARCHAR(500),
  `display_order` INT DEFAULT 0,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (widget_id) REFERENCES widgets(id) ON DELETE CASCADE,
  INDEX idx_widget_id (widget_id),
  INDEX idx_is_active (is_active),
  INDEX idx_display_order (display_order),
  UNIQUE KEY unique_widget_restaurant (widget_id, name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `votes` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `restaurant_id` INT NOT NULL,
  `widget_id` INT NOT NULL,
  `voter_id` VARCHAR(255) NOT NULL,
  `vote_timestamp` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `ip_address` VARCHAR(45),
  `user_agent` VARCHAR(500),
  FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE,
  FOREIGN KEY (widget_id) REFERENCES widgets(id) ON DELETE CASCADE,
  INDEX idx_restaurant_id (restaurant_id),
  INDEX idx_widget_id (widget_id),
  INDEX idx_voter_id (voter_id),
  INDEX idx_vote_timestamp (vote_timestamp),
  UNIQUE KEY unique_vote (widget_id, restaurant_id, voter_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin account (password: admin123)
-- In production, change this immediately
INSERT IGNORE INTO `admins` (`username`, `email`, `password_hash`, `is_active`)
VALUES ('admin', 'admin@example.com', '$2y$12$3.f7l5UHWpL1l.yfCEpf.eW7Vc6.Fb5t0pKL2qLjN8hXVLNyEMx6', 1);

-- Insert default widget
INSERT IGNORE INTO `widgets` (`name`, `api_key`, `admin_id`, `theme`, `max_restaurants`, `show_vote_count`, `voting_enabled`, `is_active`)
SELECT 'Default Widget', 'widget_key_' . SHA2(UUID(), 256), `id`, 'light', 5, 1, 1, 1
FROM `admins` WHERE `username` = 'admin' LIMIT 1;
