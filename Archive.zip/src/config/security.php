<?php
/**
 * Security Configuration & Helper Functions
 * Input validation, sanitization, and authentication
 */

// Security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');

/**
 * Sanitize user input to prevent XSS
 * @param string $input Raw input
 * @return string Sanitized output
 */
function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Validate email format
 * @param string $email Email to validate
 * @return bool Valid or not
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate URL format
 * @param string $url URL to validate
 * @return bool Valid or not
 */
function isValidUrl($url) {
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

/**
 * Hash password using bcrypt
 * @param string $password Plain password
 * @return string Hashed password
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

/**
 * Verify password against hash
 * @param string $password Plain password
 * @param string $hash Hash to verify against
 * @return bool Match or not
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generate CSRF token
 * @return string CSRF token
 */
function generateCsrfToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 * @param string $token Token to verify
 * @return bool Valid or not
 */
function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Generate secure random token
 * @param int $length Token length
 * @return string Random token
 */
function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

/**
 * Validate image upload
 * @param array $file $_FILES array
 * @return array ['valid' => bool, 'error' => string|null]
 */
function validateImageUpload($file) {
    $maxSize = 5 * 1024 * 1024; // 5MB
    $allowedMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $allowedExts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return ['valid' => false, 'error' => 'No file uploaded'];
    }
    
    if ($file['size'] > $maxSize) {
        return ['valid' => false, 'error' => 'File too large (max 5MB)'];
    }
    
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mime, $allowedMimes)) {
        return ['valid' => false, 'error' => 'Invalid file type'];
    }
    
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExts)) {
        return ['valid' => false, 'error' => 'Invalid file extension'];
    }
    
    return ['valid' => true];
}

/**
 * Generate unique filename for upload
 * @param string $originalName Original filename
 * @return string Safe unique filename
 */
function generateSafeFilename($originalName) {
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $name = uniqid('img_', true) . '.' . $ext;
    return preg_replace('/[^a-zA-Z0-9._-]/', '', $name);
}

/**
 * Sanitize filename
 * @param string $filename Filename to sanitize
 * @return string Safe filename
 */
function sanitizeFilename($filename) {
    return preg_replace('/[^a-zA-Z0-9._-]/', '', $filename);
}

/**
 * Rate limiting check
 * @param string $key Rate limit key
 * @param int $maxRequests Max requests allowed
 * @param int $timeWindow Time window in seconds
 * @return bool Allowed or not
 */
function checkRateLimit($key, $maxRequests = 10, $timeWindow = 60) {
    $sessionKey = 'ratelimit_' . $key;
    
    if (!isset($_SESSION[$sessionKey])) {
        $_SESSION[$sessionKey] = [];
    }
    
    $now = time();
    $_SESSION[$sessionKey] = array_filter($_SESSION[$sessionKey], function($timestamp) use ($now, $timeWindow) {
        return $timestamp > ($now - $timeWindow);
    });
    
    if (count($_SESSION[$sessionKey]) >= $maxRequests) {
        return false;
    }
    
    $_SESSION[$sessionKey][] = $now;
    return true;
}
