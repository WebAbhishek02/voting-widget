<?php
/**
 * Widget API - Vote Handler
 * Endpoint: /src/api/vote.php
 */

session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/security.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die(json_encode(['error' => 'Method not allowed']));
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    die(json_encode(['error' => 'Invalid JSON']));
}

$restaurantId = isset($input['restaurant_id']) ? (int)$input['restaurant_id'] : 0;
$widgetId = isset($input['widget_id']) ? (int)$input['widget_id'] : 0;

if (!$restaurantId || !$widgetId) {
    http_response_code(400);
    die(json_encode(['error' => 'Missing required parameters']));
}

// Validate widget exists and voting is enabled
$widget = queryDatabaseRow(
    'SELECT * FROM widgets WHERE id = ? AND is_active = 1 AND voting_enabled = 1',
    [$widgetId]
);

if (!$widget) {
    http_response_code(403);
    die(json_encode(['error' => 'Widget not found or voting disabled']));
}

// Validate restaurant exists and is active
$restaurant = queryDatabaseRow(
    'SELECT * FROM restaurants WHERE id = ? AND widget_id = ? AND is_active = 1',
    [$restaurantId, $widgetId]
);

if (!$restaurant) {
    http_response_code(404);
    die(json_encode(['error' => 'Restaurant not found']));
}

// Generate voter ID (persistent across sessions)
if (!isset($_SESSION['voter_id'])) {
    $_SESSION['voter_id'] = bin2hex(random_bytes(16));
}
$voterId = $_SESSION['voter_id'];

// Rate limiting: 1 vote per 5 seconds
if (!checkRateLimit('vote_' . $voterId, 1, 5)) {
    http_response_code(429);
    die(json_encode(['error' => 'Rate limited. Please wait before voting again']));
}

// Check if user has already voted for this restaurant in this widget
$existingVote = queryDatabaseRow(
    'SELECT id FROM votes WHERE widget_id = ? AND restaurant_id = ? AND voter_id = ?',
    [$widgetId, $restaurantId, $voterId]
);

if ($existingVote) {
    http_response_code(400);
    die(json_encode(['error' => 'You have already voted for this restaurant']));
}

// Record the vote
$ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$userAgent = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500);

$voteInserted = executeDatabase(
    'INSERT INTO votes (widget_id, restaurant_id, voter_id, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)',
    [$widgetId, $restaurantId, $voterId, $ipAddress, $userAgent]
);

if (!$voteInserted) {
    http_response_code(500);
    die(json_encode(['error' => 'Failed to record vote']));
}

// Get updated vote counts
$voteStats = queryDatabase(
    'SELECT 
        r.id,
        r.name,
        COUNT(v.id) as vote_count
    FROM restaurants r
    LEFT JOIN votes v ON r.id = v.restaurant_id
    WHERE r.widget_id = ?
    GROUP BY r.id
    ORDER BY r.display_order ASC',
    [$widgetId]
);

// Calculate total votes for percentages
$totalVotes = array_sum(array_column($voteStats, 'vote_count'));

// Format response
$restaurants = [];
foreach ($voteStats as $stat) {
    $percentage = $totalVotes > 0 ? round(($stat['vote_count'] / $totalVotes) * 100, 1) : 0;
    $restaurants[] = [
        'id' => (int)$stat['id'],
        'name' => $stat['name'],
        'vote_count' => (int)$stat['vote_count'],
        'percentage' => $percentage
    ];
}

http_response_code(201);
die(json_encode([
    'success' => true,
    'message' => 'Vote recorded successfully',
    'restaurant' => [
        'id' => (int)$restaurantId,
        'name' => $restaurant['name'],
        'vote_count' => $voteStats[array_search($restaurantId, array_column($voteStats, 'id'))]['vote_count'] ?? 1
    ],
    'total_votes' => $totalVotes + 1,
    'restaurants' => $restaurants
]));
