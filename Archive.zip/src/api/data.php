<?php
/**
 * Widget API - Data Retrieval
 * Endpoint: /src/api/data.php
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=300');

require_once __DIR__ . '/../config/database.php';

// Get widget ID from query parameter
$widgetId = isset($_GET['widget_id']) ? (int)$_GET['widget_id'] : 0;

if (!$widgetId) {
    http_response_code(400);
    die(json_encode(['error' => 'Widget ID required']));
}

// Validate widget exists and is active
$widget = queryDatabaseRow(
    'SELECT * FROM widgets WHERE id = ? AND is_active = 1',
    [$widgetId]
);

if (!$widget) {
    http_response_code(404);
    die(json_encode(['error' => 'Widget not found']));
}

// Get active restaurants with vote counts
$restaurants = queryDatabase(
    'SELECT 
        r.id,
        r.name,
        r.image_url,
        r.external_link,
        COUNT(v.id) as vote_count
    FROM restaurants r
    LEFT JOIN votes v ON r.id = v.restaurant_id
    WHERE r.widget_id = ? AND r.is_active = 1
    GROUP BY r.id
    ORDER BY r.display_order ASC
    LIMIT ?',
    [$widgetId, $widget['max_restaurants']]
);

// Calculate total votes and percentages
$totalVotes = array_sum(array_column($restaurants, 'vote_count'));

$formattedRestaurants = [];
foreach ($restaurants as $restaurant) {
    $percentage = $totalVotes > 0 ? round(($restaurant['vote_count'] / $totalVotes) * 100, 1) : 0;
    $formattedRestaurants[] = [
        'id' => (int)$restaurant['id'],
        'name' => sanitize($restaurant['name']),
        'image_url' => $restaurant['image_url'],
        'external_link' => $restaurant['external_link'],
        'vote_count' => (int)$restaurant['vote_count'],
        'percentage' => $percentage
    ];
}

http_response_code(200);
die(json_encode([
    'success' => true,
    'widget' => [
        'id' => (int)$widget['id'],
        'theme' => $widget['theme'],
        'show_vote_count' => (int)$widget['show_vote_count']
    ],
    'restaurants' => $formattedRestaurants,
    'total_votes' => $totalVotes
]));
