<?php
/**
 * Admin Authentication
 * Handles login and session management
 */

session_start();

require_once __DIR__ . '/../../src/config/database.php';
require_once __DIR__ . '/../../src/config/security.php';

/**
 * Check if user is authenticated
 */
function isAuthenticated() {
    return isset($_SESSION['admin_id']) && isset($_SESSION['admin_username']);
}

/**
 * Require authentication
 */
function requireAuth() {
    if (!isAuthenticated()) {
        header('Location: /public/admin/login.php');
        exit;
    }
}

/**
 * Get current admin
 */
function getCurrentAdmin() {
    if (!isAuthenticated()) {
        return null;
    }

    return queryDatabaseRow(
        'SELECT id, username, email FROM admins WHERE id = ? AND is_active = 1',
        [$_SESSION['admin_id']]
    );
}

/**
 * Login admin
 */
function loginAdmin($username, $password) {
    $username = sanitize($username);

    $admin = queryDatabaseRow(
        'SELECT id, username, password_hash FROM admins WHERE username = ? AND is_active = 1',
        [$username]
    );

    if (!$admin) {
        return ['success' => false, 'error' => 'Invalid username or password'];
    }

    if (!verifyPassword($password, $admin['password_hash'])) {
        return ['success' => false, 'error' => 'Invalid username or password'];
    }

    // Update last login
    executeDatabase(
        'UPDATE admins SET last_login = NOW() WHERE id = ?',
        [$admin['id']]
    );

    // Set session
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    return ['success' => true];
}

/**
 * Logout admin
 */
function logoutAdmin() {
    session_destroy();
}