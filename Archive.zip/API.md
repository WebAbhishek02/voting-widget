# API Documentation

Complete API reference for the Voting Widget backend.

## Base URL

```
https://yourdomain.com/src/api/
```

## Authentication

All API calls support CORS. No API key required for public endpoints (data retrieval). Vote submission is rate-limited and validated server-side.

---

## Endpoints

### 1. Get Widget Data

**Endpoint**: `GET /data.php`

**Description**: Retrieve widget configuration and restaurant data with vote counts.

**Query Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| widget_id | integer | Yes | Widget ID |

**Example Request**:

```
GET /src/api/data.php?widget_id=1
```

**Response Success (200)**:

```json
{
  "success": true,
  "widget": {
    "id": 1,
    "theme": "light",
    "show_vote_count": 1
  },
  "restaurants": [
    {
      "id": 1,
      "name": "Pizza Palace",
      "image_url": "/public/uploads/img_abc123.jpg",
      "external_link": "https://pizzapalace.com",
      "vote_count": 42,
      "percentage": 25.5
    },
    {
      "id": 2,
      "name": "Burger Kingdom",
      "image_url": "/public/uploads/img_def456.jpg",
      "external_link": "https://burgers.com",
      "vote_count": 58,
      "percentage": 35.2
    }
  ],
  "total_votes": 165
}
```

**Response Error (404)**:

```json
{
  "error": "Widget not found"
}
```

**Response Error (400)**:

```json
{
  "error": "Widget ID required"
}
```

**Caching**:

- Response is cached for 5 minutes
- Use `Cache-Control: max-age=300` header

**CORS**: Enabled for all origins

---

### 2. Submit Vote

**Endpoint**: `POST /vote.php`

**Description**: Record a vote for a restaurant. Prevents duplicate votes using localStorage and server-side validation.

**Content-Type**: `application/json`

**Request Body**:

```json
{
  "widget_id": 1,
  "restaurant_id": 5
}
```

**Request Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| widget_id | integer | Yes | Widget ID |
| restaurant_id | integer | Yes | Restaurant ID |

**Example Request**:

```bash
curl -X POST https://yourdomain.com/src/api/vote.php \
  -H "Content-Type: application/json" \
  -d '{"widget_id": 1, "restaurant_id": 5}'
```

**Response Success (201)**:

```json
{
  "success": true,
  "message": "Vote recorded successfully",
  "restaurant": {
    "id": 5,
    "name": "Taco Fiesta",
    "vote_count": 43
  },
  "total_votes": 166,
  "restaurants": [
    {
      "id": 1,
      "name": "Pizza Palace",
      "vote_count": 42,
      "percentage": 25.3
    },
    {
      "id": 2,
      "name": "Burger Kingdom",
      "vote_count": 58,
      "percentage": 34.9
    },
    {
      "id": 5,
      "name": "Taco Fiesta",
      "vote_count": 43,
      "percentage": 25.9
    }
  ]
}
```

**Response Error (400) - Missing Parameters**:

```json
{
  "error": "Missing required parameters"
}
```

**Response Error (400) - Already Voted**:

```json
{
  "error": "You have already voted for this restaurant"
}
```

**Response Error (403) - Widget Not Found**:

```json
{
  "error": "Widget not found or voting disabled"
}
```

**Response Error (404) - Restaurant Not Found**:

```json
{
  "error": "Restaurant not found"
}
```

**Response Error (429) - Rate Limited**:

```json
{
  "error": "Rate limited. Please wait before voting again"
}
```

**Response Error (500) - Server Error**:

```json
{
  "error": "Failed to record vote"
}
```

**Rate Limiting**:

- 1 vote per 5 seconds per voter
- Rate limit is session-based

**Duplicate Prevention**:

- Server maintains unique constraint: `(widget_id, restaurant_id, voter_id)`
- Client tracks voted restaurants in localStorage key: `voted_widget_{widget_id}`

**HTTP Status Codes**:
| Code | Meaning |
|------|---------|
| 200 | OK (GET requests) |
| 201 | Created (vote recorded) |
| 400 | Bad request |
| 403 | Forbidden (voting disabled) |
| 404 | Not found |
| 405 | Method not allowed |
| 429 | Too many requests |
| 500 | Server error |

---

## Data Types

### Restaurant Object

```json
{
  "id": 1,
  "name": "Restaurant Name",
  "image_url": "/public/uploads/image.jpg",
  "external_link": "https://example.com",
  "vote_count": 42,
  "percentage": 25.5
}
```

### Widget Object

```json
{
  "id": 1,
  "theme": "light",
  "show_vote_count": 1
}
```

### Vote Object (in database)

```json
{
  "id": 1,
  "restaurant_id": 5,
  "widget_id": 1,
  "voter_id": "unique-session-id",
  "vote_timestamp": "2025-12-18 14:30:00",
  "ip_address": "192.168.1.1",
  "user_agent": "Mozilla/5.0..."
}
```

---

## Error Handling

All error responses include an error message:

```json
{
  "error": "Human-readable error description"
}
```

Common error messages:

- `"Widget not found"` - Widget ID doesn't exist
- `"Widget not found or voting disabled"` - Widget disabled or not active
- `"Restaurant not found"` - Restaurant doesn't exist
- `"You have already voted for this restaurant"` - Duplicate vote
- `"Rate limited. Please wait before voting again"` - Too many votes too fast
- `"Failed to record vote"` - Database error
- `"Missing required parameters"` - Missing widget_id or restaurant_id
- `"Invalid JSON"` - Malformed request body
- `"Method not allowed"` - Wrong HTTP method

---

## CORS Headers

**Allowed Origins**: `*` (all origins)

**Allowed Methods**:

- GET
- POST
- OPTIONS

**Allowed Headers**:

- Content-Type
- Accept
- Authorization

**Response Headers**:

```
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: POST, GET, OPTIONS
Access-Control-Allow-Headers: Content-Type
```

---

## Request Examples

### JavaScript/Fetch

```javascript
// Get widget data
fetch("https://yourdomain.com/src/api/data.php?widget_id=1")
  .then((response) => response.json())
  .then((data) => console.log(data));

// Submit vote
fetch("https://yourdomain.com/src/api/vote.php", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    widget_id: 1,
    restaurant_id: 5,
  }),
})
  .then((response) => response.json())
  .then((data) => console.log(data));
```

### cURL

```bash
# Get widget data
curl https://yourdomain.com/src/api/data.php?widget_id=1

# Submit vote
curl -X POST https://yourdomain.com/src/api/vote.php \
  -H "Content-Type: application/json" \
  -d '{"widget_id": 1, "restaurant_id": 5}'
```

### Python

```python
import requests
import json

# Get widget data
response = requests.get('https://yourdomain.com/src/api/data.php',
                       params={'widget_id': 1})
data = response.json()
print(data)

# Submit vote
vote_data = {
    'widget_id': 1,
    'restaurant_id': 5
}
response = requests.post('https://yourdomain.com/src/api/vote.php',
                        json=vote_data)
data = response.json()
print(data)
```

### PHP

```php
// Get widget data
$url = 'https://yourdomain.com/src/api/data.php?widget_id=1';
$response = file_get_contents($url);
$data = json_decode($response, true);
print_r($data);

// Submit vote
$url = 'https://yourdomain.com/src/api/vote.php';
$data = [
    'widget_id' => 1,
    'restaurant_id' => 5
];
$options = [
    'http' => [
        'method' => 'POST',
        'header' => 'Content-Type: application/json',
        'content' => json_encode($data)
    ]
];
$response = file_get_contents($url, false, stream_context_create($options));
$result = json_decode($response, true);
print_r($result);
```

---

## Security Considerations

### Input Validation

- All numeric inputs validated as integers
- JSON input validated and sanitized
- SQL injection prevented via prepared statements

### Vote Validation

- Unique constraint prevents duplicate votes
- Server validates voter hasn't voted for restaurant
- Rate limiting prevents abuse
- IP address and user agent logged

### CSRF Protection

- Vote endpoint validates rate limiting per session
- No token required (stateless API)

### Output Escaping

- All text fields HTML escaped in responses
- URLs validated before inclusion

---

## Rate Limiting

Vote endpoint enforces rate limiting:

- **Max requests**: 1 vote per person
- **Time window**: 5 seconds
- **Strategy**: Session-based (per browser/session)

Rate limit resets after time window expires.

---

## Caching Strategy

### Data Endpoint

- Response cached: 5 minutes
- Cache header: `Cache-Control: public, max-age=300`
- Use ETags for client-side caching

### Vote Endpoint

- No caching
- Real-time updates to vote counts

### Static Assets

- CSS/JS: 7 days
- Images: 30 days
- Fonts: 1 year

---

## Monitoring & Analytics

Data captured with each vote:

- `voter_id`: Unique identifier (browser session)
- `ip_address`: Voter IP address
- `user_agent`: Browser information
- `vote_timestamp`: When vote was cast

This enables:

- Vote trend analysis
- Duplicate vote detection
- Abuse prevention
- Geographic distribution (IP-based)

---

## API Versioning

Current version: **1.0**

No versioning suffix needed. Future versions will maintain backward compatibility or be released as `/api/v2/` endpoints.

---

## Support & Documentation

- **Full README**: See `README.md`
- **Deployment Guide**: See `DEPLOYMENT.md`
- **Quick Start**: See `QUICKSTART.md`
- **Embed Examples**: See `EMBED_EXAMPLE.html`

---

**Last Updated**: 2025-12-18  
**API Version**: 1.0
