# Production Deployment Guide

## Pre-Deployment Checklist

### Server Requirements

- PHP 8.0+ with extensions: PDO, PDO_MySQL, GD (for images)
- MySQL 5.7+ or MariaDB 10.2+
- 100MB minimum disk space
- SSL/TLS certificate (HTTPS)

### Hosting Options

- Shared Hosting (cPanel, Plesk)
- VPS (DigitalOcean, Linode, AWS)
- Dedicated Server
- Local Server (development)

---

## Step 1: Download & Extract

```bash
# Download the application (via FTP or Git)
# If using Git:
git clone <repository-url> /path/to/voting-widget
cd /path/to/voting-widget

# Or via FTP:
# Upload all files to your web root directory
```

---

## Step 2: Database Setup

### Local Development

```bash
mysql -u root -p < database/schema.sql
```

### Shared Hosting (cPanel)

1. Go to cPanel → Databases → MySQL Databases
2. Create new database (e.g., `voting_widget`)
3. Create new MySQL user (e.g., `voting_user`)
4. Add user to database with all privileges
5. Use phpMyAdmin to import `database/schema.sql`

### Remote Server

```bash
# SSH into server
ssh user@domain.com

# Create database
mysql -u admin -p -e "CREATE DATABASE voting_widget;"
mysql -u admin -p -e "GRANT ALL PRIVILEGES ON voting_widget.* TO 'voting_user'@'localhost' IDENTIFIED BY 'strong_password';"
mysql -u admin -p -e "FLUSH PRIVILEGES;"

# Import schema
mysql -u admin -p voting_widget < database/schema.sql
```

---

## Step 3: Configure Application

### Update Database Credentials

Edit `/src/config/database.php`:

```php
define('DB_HOST', 'your-db-host');      // localhost, or remote host
define('DB_NAME', 'voting_widget');
define('DB_USER', 'voting_user');
define('DB_PASS', 'your-strong-password');
```

### Set File Permissions

```bash
# Navigate to project directory
cd /path/to/voting-widget

# Set correct permissions
chmod 755 public
chmod 755 public/uploads
chmod 755 public/widget
chmod 755 public/admin
chmod 755 src
chmod 755 src/config
chmod 755 src/api
chmod 755 src/admin
chmod 644 public/uploads/.gitkeep
chmod 640 src/config/*.php

# Create .htaccess for uploads (prevent PHP execution)
cat > public/uploads/.htaccess << 'EOF'
# Prevent PHP execution in uploads directory
<FilesMatch "\.php$">
    Order Deny,Allow
    Deny from all
</FilesMatch>

# Allow images
<FilesMatch "\.(?:jpg|jpeg|png|gif|webp)$">
    Order Allow,Deny
    Allow from all
</FilesMatch>
EOF
```

---

## Step 4: Change Default Credentials

### Update Admin Password

```bash
# SSH into server or use phpMyAdmin

# Via MySQL CLI:
mysql -u voting_user -p voting_widget << 'EOF'

-- Change default admin password (admin123 -> your new password)
UPDATE admins
SET password_hash = '$2y$12$YOUR_BCRYPT_HASH_HERE'
WHERE username = 'admin';

EOF
```

To generate bcrypt hash:

```php
<?php
echo password_hash('your-new-password', PASSWORD_BCRYPT);
?>
```

### Create New Admin Account (Recommended)

```php
<?php
$hash = password_hash('secure_password_123', PASSWORD_BCRYPT);
echo "INSERT INTO admins (username, email, password_hash, is_active)
      VALUES ('newadmin', 'admin@yourdomain.com', '$hash', 1);";
?>
```

Then delete default admin:

```sql
DELETE FROM admins WHERE username = 'admin';
```

---

## Step 5: Configure Web Server

### Apache (.htaccess)

Create `.htaccess` in root:

```apache
# Enable mod_rewrite
RewriteEngine On
RewriteBase /

# Security headers
<IfModule mod_headers.c>
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-XSS-Protection "1; mode=block"
    Header set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>

# Disable directory listing
Options -Indexes

# Protect config files
<FilesMatch "^(config|src|database)" >
    Order allow,deny
    Deny from all
</FilesMatch>

# PHP security
<FilesMatch "\.php$">
    SetHandler "proxy:unix:/run/php-fpm.sock|fcgi://localhost"
</FilesMatch>
```

### Nginx

Create nginx config:

```nginx
server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    ssl_certificate /path/to/certificate.crt;
    ssl_certificate_key /path/to/private.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    root /var/www/voting-widget/public;
    index index.html index.php;

    # Security headers
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Protect sensitive files
    location ~ /\. {
        deny all;
    }

    location ~ ~$ {
        deny all;
    }

    # Uploads directory
    location /public/uploads {
        try_files $uri =404;
    }

    # Protected directories
    location ~ ^/(src|database|config)/ {
        deny all;
    }

    # PHP
    location ~ \.php$ {
        try_files $uri =404;
        fastcgi_pass unix:/run/php-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # Redirect HTTP to HTTPS
    if ($scheme != "https") {
        return 301 https://$server_name$request_uri;
    }
}
```

---

## Step 6: SSL Certificate Setup

### Let's Encrypt (Free)

```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-apache

# Generate certificate
sudo certbot certonly --apache -d yourdomain.com -d www.yourdomain.com

# Auto-renewal
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer
```

### Shared Hosting

- Use cPanel Auto SSL
- Or upload certificate via cPanel

---

## Step 7: Database Backups

### Automated Backup Script

Create `/backup.sh`:

```bash
#!/bin/bash

BACKUP_DIR="/home/user/backups"
DB_NAME="voting_widget"
DB_USER="voting_user"
DB_PASS="password"
DATE=$(date +%Y%m%d_%H%M%S)

# Create backup
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME > $BACKUP_DIR/backup_$DATE.sql

# Compress
gzip $BACKUP_DIR/backup_$DATE.sql

# Keep only last 30 days
find $BACKUP_DIR -name "backup_*.sql.gz" -mtime +30 -delete

echo "Backup completed: $BACKUP_DIR/backup_$DATE.sql.gz"
```

Setup cron:

```bash
# Run daily at 2 AM
crontab -e

# Add line:
0 2 * * * /path/to/backup.sh
```

---

## Step 8: Monitoring & Logging

### PHP Error Logging

Edit `php.ini`:

```ini
error_log = /var/log/php-errors.log
log_errors = On
display_errors = Off
```

### Application Logging

Create `/src/config/logger.php`:

```php
<?php
function logError($message, $context = []) {
    $log = date('Y-m-d H:i:s') . ' - ' . $message;
    if ($context) {
        $log .= ' | ' . json_encode($context);
    }
    error_log($log . "\n", 3, __DIR__ . '/../../logs/error.log');
}

function logAccess($action, $userId = null) {
    $log = date('Y-m-d H:i:s') . ' - ' . $action;
    if ($userId) {
        $log .= ' (User: ' . $userId . ')';
    }
    error_log($log . "\n", 3, __DIR__ . '/../../logs/access.log');
}
```

---

## Step 9: Performance Optimization

### PHP-FPM Configuration

Edit `/etc/php-fpm.d/voting-widget.conf`:

```ini
[voting-widget]
user = www-data
group = www-data
listen = /run/php-fpm-voting-widget.sock
pm = dynamic
pm.max_children = 50
pm.start_servers = 5
pm.min_spare_servers = 5
pm.max_spare_servers = 20
pm.max_requests = 500
```

### MySQL Optimization

```sql
-- Add indexes (already in schema)
-- Optimize tables
OPTIMIZE TABLE admins, widgets, restaurants, votes;

-- Analyze tables
ANALYZE TABLE admins, widgets, restaurants, votes;
```

### CDN Setup

Configure CloudFlare or similar:

- Static asset caching (CSS, JS, images)
- Automatic HTTPS
- DDoS protection
- Image optimization

---

## Step 10: Testing

### Pre-Launch Tests

```bash
# 1. Database connection
curl https://yourdomain.com/public/admin/login.php

# 2. Admin login
# Login with new credentials

# 3. Create widget
# Go to Widgets page and create test widget

# 4. Add restaurants
# Add 3-5 test restaurants

# 5. Test voting
# Vote for restaurants on demo page

# 6. Check vote counts
# Verify votes appear in admin panel

# 7. Test embeds
# Create test page with embed code

# 8. Cross-browser testing
# Test on Chrome, Firefox, Safari, Edge
# Test on mobile devices

# 9. Load testing
# Simulate concurrent users (ab, wrk, or LoadImpact)

# 10. Security audit
# Run OWASP ZAP or similar
# Check for vulnerabilities
```

---

## Step 11: Post-Deployment

### Monitoring Setup

1. Set up uptime monitoring (UptimeRobot, Pingdom)
2. Configure error email alerts
3. Monitor database size and backups
4. Track server resources (CPU, RAM, Disk)

### Documentation

1. Create runbook for common tasks
2. Document custom configurations
3. Maintain access credentials securely
4. Keep deployment history

### Updates

1. Monitor PHP security updates
2. Update MySQL regularly
3. Review dependencies
4. Test updates before deploying

---

## Troubleshooting

### Common Issues

**Issue: Database connection error**

```
Solution:
1. Verify credentials in database.php
2. Check MySQL server is running
3. Verify user permissions: GRANT ALL ON db.* TO user@host
4. Check firewall rules allow connection
```

**Issue: Image upload fails**

```
Solution:
1. Check uploads directory is writable: chmod 755 public/uploads
2. Check PHP upload_max_filesize: php.ini
3. Check disk space availability
4. Verify file permissions on uploaded files
```

**Issue: Admin login not working**

```
Solution:
1. Verify user exists: SELECT * FROM admins;
2. Test password hash: password_verify('password', hash)
3. Check session configuration in php.ini
4. Clear browser cookies and try again
```

**Issue: Widget not loading on external site**

```
Solution:
1. Check CORS headers
2. Verify widget-id parameter is correct
3. Check API endpoints are accessible
4. Verify HTTPS if embedded on HTTPS site
5. Check browser console for errors
```

---

## Security Checklist

- [ ] Changed default admin password
- [ ] Configured database credentials
- [ ] Set proper file permissions
- [ ] Enabled HTTPS/SSL
- [ ] Configured security headers
- [ ] Set up backups
- [ ] Disabled directory listing
- [ ] Protected sensitive files
- [ ] Configured error logging
- [ ] Tested all functionality
- [ ] Set up monitoring
- [ ] Reviewed database access
- [ ] Configured firewall rules
- [ ] Updated all dependencies
- [ ] Ran security audit

---

## Support Contact

For deployment assistance or issues:

- Check application logs: `/logs/` directory
- Review PHP error logs: check php.ini error_log path
- Test API endpoints directly
- Verify all file permissions
- Check server resources are sufficient

---

**Last Updated**: 2025-12-18  
**Version**: 1.0
