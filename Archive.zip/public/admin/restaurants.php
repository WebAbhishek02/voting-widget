<?php
/**
 * Admin - Restaurant Management
 */

session_start();

require_once __DIR__ . '/../../src/config/database.php';
require_once __DIR__ . '/../../src/config/security.php';
require_once __DIR__ . '/../../src/admin/auth.php';

requireAuth();

$admin = getCurrentAdmin();
$widgetId = isset($_GET['widget_id']) ? (int)$_GET['widget_id'] : 0;
$action = $_GET['action'] ?? 'list';
$restaurantId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Validate widget belongs to admin
$widget = queryDatabaseRow(
    'SELECT * FROM widgets WHERE id = ? AND admin_id = ?',
    [$widgetId, $admin['id']]
);

if (!$widget) {
    die('Widget not found');
}

$error = '';
$success = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Security token invalid';
    } else {
        $postAction = $_POST['action'] ?? '';

        if ($postAction === 'add') {
            // Add restaurant
            $name = sanitize($_POST['name'] ?? '');
            $link = $_POST['link'] ?? '';
            $image = $_FILES['image'] ?? null;

            if (!$name) {
                $error = 'Restaurant name is required';
            } else {
                $imageUrl = null;

                if ($image && $image['tmp_name']) {
                    $validation = validateImageUpload($image);
                    if (!$validation['valid']) {
                        $error = $validation['error'];
                    } else {
                        $filename = generateSafeFilename($image['name']);
                        $uploadPath = __DIR__ . '/../../public/uploads/' . $filename;

                        if (move_uploaded_file($image['tmp_name'], $uploadPath)) {
                            $imageUrl = '/public/uploads/' . $filename;
                        } else {
                            $error = 'Failed to upload image';
                        }
                    }
                }

                if (!$error) {
                    $maxOrder = queryDatabaseRow(
                        'SELECT MAX(display_order) as max_order FROM restaurants WHERE widget_id = ?',
                        [$widgetId]
                    )['max_order'] ?? 0;

                    $inserted = executeDatabase(
                        'INSERT INTO restaurants (widget_id, name, image_url, external_link, display_order) VALUES (?, ?, ?, ?, ?)',
                        [$widgetId, $name, $imageUrl, $link ?: null, $maxOrder + 1]
                    );

                    if ($inserted) {
                        $success = 'Restaurant added successfully';
                        header('Location: ?page=restaurants&widget_id=' . $widgetId);
                        exit;
                    } else {
                        $error = 'Failed to add restaurant';
                    }
                }
            }
        } elseif ($postAction === 'edit') {
            // Edit restaurant
            $name = sanitize($_POST['name'] ?? '');
            $link = $_POST['link'] ?? '';
            $restaurantId = (int)$_POST['restaurant_id'];

            if (!$name) {
                $error = 'Restaurant name is required';
            } else {
                $restaurant = queryDatabaseRow(
                    'SELECT * FROM restaurants WHERE id = ? AND widget_id = ?',
                    [$restaurantId, $widgetId]
                );

                if (!$restaurant) {
                    $error = 'Restaurant not found';
                } else {
                    $imageUrl = $restaurant['image_url'];

                    if (isset($_FILES['image']) && $_FILES['image']['tmp_name']) {
                        $validation = validateImageUpload($_FILES['image']);
                        if (!$validation['valid']) {
                            $error = $validation['error'];
                        } else {
                            // Delete old image
                            if ($imageUrl && file_exists(__DIR__ . '/../../public' . $imageUrl)) {
                                @unlink(__DIR__ . '/../../public' . $imageUrl);
                            }

                            $filename = generateSafeFilename($_FILES['image']['name']);
                            $uploadPath = __DIR__ . '/../../public/uploads/' . $filename;

                            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
                                $imageUrl = '/public/uploads/' . $filename;
                            } else {
                                $error = 'Failed to upload image';
                            }
                        }
                    }

                    if (!$error) {
                        $updated = executeDatabase(
                            'UPDATE restaurants SET name = ?, image_url = ?, external_link = ? WHERE id = ?',
                            [$name, $imageUrl, $link ?: null, $restaurantId]
                        );

                        if ($updated) {
                            $success = 'Restaurant updated successfully';
                            header('Location: ?page=restaurants&widget_id=' . $widgetId);
                            exit;
                        } else {
                            $error = 'Failed to update restaurant';
                        }
                    }
                }
            }
        } elseif ($postAction === 'delete') {
            // Delete restaurant
            $restaurantId = (int)$_POST['restaurant_id'];

            $restaurant = queryDatabaseRow(
                'SELECT * FROM restaurants WHERE id = ? AND widget_id = ?',
                [$restaurantId, $widgetId]
            );

            if ($restaurant) {
                if ($restaurant['image_url'] && file_exists(__DIR__ . '/../../public' . $restaurant['image_url'])) {
                    @unlink(__DIR__ . '/../../public' . $restaurant['image_url']);
                }

                executeDatabase('DELETE FROM restaurants WHERE id = ?', [$restaurantId]);
                $success = 'Restaurant deleted successfully';
            }

            header('Location: ?page=restaurants&widget_id=' . $widgetId);
            exit;
        } elseif ($postAction === 'reorder') {
            // Reorder restaurants
            $order = $_POST['order'] ?? [];

            foreach ($order as $index => $id) {
                executeDatabase(
                    'UPDATE restaurants SET display_order = ? WHERE id = ? AND widget_id = ?',
                    [$index, (int)$id, $widgetId]
                );
            }

            $success = 'Order updated successfully';
            header('Location: ?page=restaurants&widget_id=' . $widgetId);
            exit;
        } elseif ($postAction === 'toggle') {
            // Toggle restaurant active status
            $restaurantId = (int)$_POST['restaurant_id'];

            $restaurant = queryDatabaseRow(
                'SELECT * FROM restaurants WHERE id = ? AND widget_id = ?',
                [$restaurantId, $widgetId]
            );

            if ($restaurant) {
                executeDatabase(
                    'UPDATE restaurants SET is_active = ? WHERE id = ?',
                    [!$restaurant['is_active'], $restaurantId]
                );
                $success = 'Restaurant status updated';
            }

            header('Location: ?page=restaurants&widget_id=' . $widgetId);
            exit;
        }
    }
}

// Get restaurants
$restaurants = queryDatabase(
    'SELECT * FROM restaurants WHERE widget_id = ? ORDER BY display_order ASC',
    [$widgetId]
);

$csrfToken = generateCsrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Restaurants - Voting Widget</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f5f7fa;
            color: #333;
        }

        .admin-wrapper {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar-header h2 {
            font-size: 20px;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 12px;
            opacity: 0.8;
        }

        .sidebar-nav {
            list-style: none;
        }

        .sidebar-nav li {
            margin-bottom: 10px;
        }

        .sidebar-nav a {
            display: block;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
        }

        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }

        .sidebar-footer {
            position: absolute;
            bottom: 20px;
            left: 20px;
            right: 20px;
        }

        .logout-btn {
            width: 100%;
            padding: 10px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .main-content {
            margin-left: 250px;
            flex: 1;
            padding: 30px;
        }

        .top-bar {
            background: white;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-bar h1 {
            font-size: 24px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .alert-error {
            background: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }

        .alert-success {
            background: #efe;
            color: #3c3;
            border: 1px solid #cfc;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5568d3;
        }

        .btn-secondary {
            background: #e5e7eb;
            color: #333;
        }

        .btn-secondary:hover {
            background: #d1d5db;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        /* Forms */
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            max-width: 600px;
        }

        .form-container h2 {
            margin-bottom: 20px;
            font-size: 18px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #333;
            font-size: 14px;
        }

        input[type="text"],
        input[type="url"],
        input[type="file"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            font-family: inherit;
        }

        input[type="text"]:focus,
        input[type="url"]:focus,
        input[type="file"]:focus,
        textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .btn-submit {
            flex: 1;
        }

        /* Restaurants List */
        .restaurants-section {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .section-header {
            padding: 20px 30px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .section-header h2 {
            font-size: 18px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f9fafb;
            border-bottom: 2px solid #e5e7eb;
        }

        th {
            padding: 15px 20px;
            text-align: left;
            font-weight: 600;
            color: #666;
            font-size: 13px;
            text-transform: uppercase;
        }

        td {
            padding: 15px 20px;
            border-bottom: 1px solid #e5e7eb;
        }

        tbody tr:hover {
            background: #f9fafb;
        }

        .restaurant-image {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 4px;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
        }

        .empty-state {
            padding: 40px 20px;
            text-align: center;
            color: #999;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 15px;
            }

            .main-content {
                margin-left: 0;
                padding: 15px;
            }

            .form-container {
                max-width: 100%;
            }

            .top-bar {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Voting Widget</h2>
                <p>Admin Panel</p>
            </div>

            <nav>
                <ul class="sidebar-nav">
                    <li><a href="/public/admin/index.php">Dashboard</a></li>
                    <li><a href="?page=restaurants" class="active">Restaurants</a></li>
                    <li><a href="?page=votes">Votes</a></li>
                    <li><a href="?page=widgets">Widgets</a></li>
                    <li><a href="?page=settings">Settings</a></li>
                </ul>
            </nav>

            <div class="sidebar-footer">
                <form method="POST" action="/public/admin/logout.php">
                    <button type="submit" class="logout-btn">Logout</button>
                </form>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <h1>Manage Restaurants</h1>
                <a href="/public/admin/index.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <!-- Add Restaurant Form -->
            <div class="form-container">
                <h2>Add New Restaurant</h2>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                    <input type="hidden" name="action" value="add">

                    <div class="form-group">
                        <label for="name">Restaurant Name *</label>
                        <input type="text" id="name" name="name" required>
                    </div>

                    <div class="form-group">
                        <label for="link">External Link (Optional)</label>
                        <input type="url" id="link" name="link" placeholder="https://example.com">
                    </div>

                    <div class="form-group">
                        <label for="image">Restaurant Image (JPG, PNG, GIF, WebP - Max 5MB)</label>
                        <input type="file" id="image" name="image" accept="image/*">
                    </div>

                    <div class="form-buttons">
                        <button type="submit" class="btn btn-primary btn-submit">Add Restaurant</button>
                    </div>
                </form>
            </div>

            <!-- Restaurants List -->
            <div class="restaurants-section">
                <div class="section-header">
                    <h2>Restaurants (<?php echo count($restaurants); ?>)</h2>
                </div>

                <?php if ($restaurants): ?>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($restaurants as $r): ?>
                                    <tr>
                                        <td>
                                            <?php if ($r['image_url']): ?>
                                                <img src="<?php echo htmlspecialchars($r['image_url']); ?>" alt="<?php echo htmlspecialchars($r['name']); ?>" class="restaurant-image">
                                            <?php else: ?>
                                                <span style="color: #999;">No image</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($r['name']); ?></td>
                                        <td>
                                            <?php echo $r['is_active'] ? '<span style="color: #10b981;">Active</span>' : '<span style="color: #999;">Inactive</span>'; ?>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="?page=restaurants&widget_id=<?php echo $widgetId; ?>&action=edit&id=<?php echo $r['id']; ?>" class="btn btn-secondary btn-small">Edit</a>
                                                <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this restaurant?');">
                                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="restaurant_id" value="<?php echo $r['id']; ?>">
                                                    <button type="submit" class="btn btn-danger btn-small">Delete</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <p>No restaurants added yet. Create one above!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
