<?php
/**
 * Admin - Votes Management
 */

session_start();

require_once __DIR__ . '/../../src/config/database.php';
require_once __DIR__ . '/../../src/config/security.php';
require_once __DIR__ . '/../../src/admin/auth.php';

requireAuth();

$admin = getCurrentAdmin();
$action = $_GET['action'] ?? 'list';
$widgetId = isset($_GET['widget_id']) ? (int)$_GET['widget_id'] : 0;

// Get admin's widgets
$widgets = queryDatabase(
    'SELECT id, name FROM widgets WHERE admin_id = ?',
    [$admin['id']]
);

// Default to first widget if not specified
if (!$widgetId && $widgets) {
    $widgetId = $widgets[0]['id'];
}

$error = '';
$success = '';

// Handle vote reset
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Security token invalid';
    } else {
        $postAction = $_POST['action'] ?? '';

        if ($postAction === 'reset_restaurant') {
            $restaurantId = (int)$_POST['restaurant_id'];

            $restaurant = queryDatabaseRow(
                'SELECT r.* FROM restaurants r
                 JOIN widgets w ON r.widget_id = w.id
                 WHERE r.id = ? AND w.admin_id = ?',
                [$restaurantId, $admin['id']]
            );

            if ($restaurant) {
                executeDatabase('DELETE FROM votes WHERE restaurant_id = ?', [$restaurantId]);
                $success = 'Votes for this restaurant have been reset';
            }
        } elseif ($postAction === 'reset_widget') {
            $wId = (int)$_POST['widget_id'];

            $widget = queryDatabaseRow(
                'SELECT * FROM widgets WHERE id = ? AND admin_id = ?',
                [$wId, $admin['id']]
            );

            if ($widget) {
                executeDatabase(
                    'DELETE FROM votes WHERE widget_id = ?',
                    [$wId]
                );
                $success = 'All votes for this widget have been reset';
            }
        }
    }
}

// Get votes data
$voteStats = queryDatabase(
    'SELECT 
        r.id,
        r.name,
        r.widget_id,
        COUNT(v.id) as vote_count
    FROM restaurants r
    LEFT JOIN votes v ON r.id = v.restaurant_id
    WHERE r.widget_id = ?
    GROUP BY r.id
    ORDER BY vote_count DESC',
    [$widgetId]
);

$totalVotes = array_sum(array_column($voteStats, 'vote_count'));

$csrfToken = generateCsrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Votes - Voting Widget</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f5f7fa;
            color: #333;
        }

        .admin-wrapper {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar-header h2 {
            font-size: 20px;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 12px;
            opacity: 0.8;
        }

        .sidebar-nav {
            list-style: none;
        }

        .sidebar-nav li {
            margin-bottom: 10px;
        }

        .sidebar-nav a {
            display: block;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
        }

        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }

        .sidebar-footer {
            position: absolute;
            bottom: 20px;
            left: 20px;
            right: 20px;
        }

        .logout-btn {
            width: 100%;
            padding: 10px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .main-content {
            margin-left: 250px;
            flex: 1;
            padding: 30px;
        }

        .top-bar {
            background: white;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-bar h1 {
            font-size: 24px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .alert-error {
            background: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }

        .alert-success {
            background: #efe;
            color: #3c3;
            border: 1px solid #cfc;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5568d3;
        }

        .btn-secondary {
            background: #e5e7eb;
            color: #333;
        }

        .btn-secondary:hover {
            background: #d1d5db;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
        }

        .widget-selector {
            margin-bottom: 30px;
            background: white;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-left: 4px solid #667eea;
        }

        .stat-card h3 {
            color: #666;
            font-size: 12px;
            text-transform: uppercase;
            margin-bottom: 10px;
        }

        .stat-card .value {
            font-size: 32px;
            font-weight: 700;
            color: #333;
        }

        .votes-section {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .section-header {
            padding: 20px 30px;
            border-bottom: 1px solid #e5e7eb;
        }

        .section-header h2 {
            font-size: 18px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f9fafb;
            border-bottom: 2px solid #e5e7eb;
        }

        th {
            padding: 15px 20px;
            text-align: left;
            font-weight: 600;
            color: #666;
            font-size: 13px;
            text-transform: uppercase;
        }

        td {
            padding: 15px 20px;
            border-bottom: 1px solid #e5e7eb;
        }

        tbody tr:hover {
            background: #f9fafb;
        }

        .progress-bar {
            width: 100%;
            height: 20px;
            background: #e5e7eb;
            border-radius: 3px;
            overflow: hidden;
            margin: 5px 0;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 3px;
            transition: width 0.3s;
        }

        .empty-state {
            padding: 40px 20px;
            text-align: center;
            color: #999;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 15px;
            }

            .main-content {
                margin-left: 0;
                padding: 15px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .top-bar {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Voting Widget</h2>
                <p>Admin Panel</p>
            </div>

            <nav>
                <ul class="sidebar-nav">
                    <li><a href="/public/admin/index.php">Dashboard</a></li>
                    <li><a href="?page=restaurants">Restaurants</a></li>
                    <li><a href="?page=votes" class="active">Votes</a></li>
                    <li><a href="?page=widgets">Widgets</a></li>
                    <li><a href="?page=settings">Settings</a></li>
                </ul>
            </nav>

            <div class="sidebar-footer">
                <form method="POST" action="/public/admin/logout.php">
                    <button type="submit" class="logout-btn">Logout</button>
                </form>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <h1>Manage Votes</h1>
                <a href="/public/admin/index.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <!-- Widget Selector -->
            <?php if (count($widgets) > 1): ?>
                <div class="widget-selector">
                    <label for="widget-select">Select Widget:</label>
                    <select id="widget-select" onchange="window.location.href='?page=votes&widget_id=' + this.value">
                        <?php foreach ($widgets as $w): ?>
                            <option value="<?php echo $w['id']; ?>" <?php echo $w['id'] == $widgetId ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($w['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>

            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Votes</h3>
                    <div class="value"><?php echo $totalVotes; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Restaurants</h3>
                    <div class="value"><?php echo count($voteStats); ?></div>
                </div>
            </div>

            <!-- Votes by Restaurant -->
            <div class="votes-section">
                <div class="section-header">
                    <h2>Votes by Restaurant</h2>
                </div>

                <?php if ($voteStats): ?>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Restaurant</th>
                                    <th>Votes</th>
                                    <th>Percentage</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($voteStats as $stat): ?>
                                    <?php $percentage = $totalVotes > 0 ? ($stat['vote_count'] / $totalVotes) * 100 : 0; ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($stat['name']); ?></td>
                                        <td><?php echo (int)$stat['vote_count']; ?></td>
                                        <td>
                                            <div class="progress-bar">
                                                <div class="progress-fill" style="width: <?php echo $percentage; ?>%"></div>
                                            </div>
                                            <?php echo number_format($percentage, 1); ?>%
                                        </td>
                                        <td>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Reset votes for this restaurant?');">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                                                <input type="hidden" name="action" value="reset_restaurant">
                                                <input type="hidden" name="restaurant_id" value="<?php echo $stat['id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-small">Reset</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div style="padding: 20px 30px; border-top: 1px solid #e5e7eb;">
                        <form method="POST" onsubmit="return confirm('Reset ALL votes for this widget?');">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            <input type="hidden" name="action" value="reset_widget">
                            <input type="hidden" name="widget_id" value="<?php echo $widgetId; ?>">
                            <button type="submit" class="btn btn-danger">Reset All Votes</button>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <p>No vote data available for this widget yet.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
