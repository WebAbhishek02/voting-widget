<?php
/**
 * Admin Settings Page
 */

session_start();

require_once __DIR__ . '/../../src/config/database.php';
require_once __DIR__ . '/../../src/config/security.php';
require_once __DIR__ . '/../../src/admin/auth.php';

requireAuth();

$admin = getCurrentAdmin();
$error = '';
$success = '';

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Security token invalid';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'change_password') {
            $currentPassword = $_POST['current_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';

            if (!$currentPassword || !$newPassword || !$confirmPassword) {
                $error = 'All password fields are required';
            } elseif ($newPassword !== $confirmPassword) {
                $error = 'New passwords do not match';
            } elseif (strlen($newPassword) < 8) {
                $error = 'Password must be at least 8 characters';
            } else {
                $adminData = queryDatabaseRow(
                    'SELECT password_hash FROM admins WHERE id = ?',
                    [$admin['id']]
                );

                if (!verifyPassword($currentPassword, $adminData['password_hash'])) {
                    $error = 'Current password is incorrect';
                } else {
                    $newHash = hashPassword($newPassword);
                    $updated = executeDatabase(
                        'UPDATE admins SET password_hash = ? WHERE id = ?',
                        [$newHash, $admin['id']]
                    );

                    if ($updated) {
                        $success = 'Password changed successfully';
                    } else {
                        $error = 'Failed to update password';
                    }
                }
            }
        }
    }
}

$csrfToken = generateCsrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Voting Widget</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f5f7fa;
            color: #333;
        }

        .admin-wrapper {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar-header h2 {
            font-size: 20px;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 12px;
            opacity: 0.8;
        }

        .sidebar-nav {
            list-style: none;
        }

        .sidebar-nav li {
            margin-bottom: 10px;
        }

        .sidebar-nav a {
            display: block;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
        }

        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }

        .sidebar-footer {
            position: absolute;
            bottom: 20px;
            left: 20px;
            right: 20px;
        }

        .logout-btn {
            width: 100%;
            padding: 10px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .main-content {
            margin-left: 250px;
            flex: 1;
            padding: 30px;
        }

        .top-bar {
            background: white;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-bar h1 {
            font-size: 24px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .alert-error {
            background: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }

        .alert-success {
            background: #efe;
            color: #3c3;
            border: 1px solid #cfc;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5568d3;
        }

        .btn-secondary {
            background: #e5e7eb;
            color: #333;
        }

        .btn-secondary:hover {
            background: #d1d5db;
        }

        .settings-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 30px;
            max-width: 600px;
        }

        .settings-container h2 {
            margin-bottom: 25px;
            font-size: 18px;
            border-bottom: 2px solid #667eea;
            padding-bottom: 15px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #333;
            font-size: 14px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            font-family: inherit;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .info-box {
            background: #f9fafb;
            padding: 15px;
            border-radius: 6px;
            border-left: 4px solid #667eea;
            margin-bottom: 20px;
        }

        .info-box p {
            margin: 5px 0;
            font-size: 14px;
        }

        .form-buttons {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        .btn-submit {
            flex: 1;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 15px;
            }

            .main-content {
                margin-left: 0;
                padding: 15px;
            }

            .settings-container {
                max-width: 100%;
                padding: 20px;
            }

            .top-bar {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Voting Widget</h2>
                <p>Admin Panel</p>
            </div>

            <nav>
                <ul class="sidebar-nav">
                    <li><a href="/public/admin/index.php">Dashboard</a></li>
                    <li><a href="?page=restaurants">Restaurants</a></li>
                    <li><a href="?page=votes">Votes</a></li>
                    <li><a href="?page=widgets">Widgets</a></li>
                    <li><a href="?page=settings" class="active">Settings</a></li>
                </ul>
            </nav>

            <div class="sidebar-footer">
                <form method="POST" action="/public/admin/logout.php">
                    <button type="submit" class="logout-btn">Logout</button>
                </form>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <h1>Settings</h1>
                <a href="/public/admin/index.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <!-- Account Information -->
            <div class="settings-container">
                <h2>Account Information</h2>

                <div class="info-box">
                    <p><strong>Username:</strong> <?php echo htmlspecialchars($admin['username']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($admin['email']); ?></p>
                </div>
            </div>

            <!-- Change Password -->
            <div class="settings-container" style="margin-top: 30px;">
                <h2>Change Password</h2>

                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                    <input type="hidden" name="action" value="change_password">

                    <div class="form-group">
                        <label for="current_password">Current Password *</label>
                        <input type="password" id="current_password" name="current_password" required>
                    </div>

                    <div class="form-group">
                        <label for="new_password">New Password *</label>
                        <input type="password" id="new_password" name="new_password" required minlength="8">
                        <small style="color: #666; display: block; margin-top: 5px;">Minimum 8 characters</small>
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password *</label>
                        <input type="password" id="confirm_password" name="confirm_password" required minlength="8">
                    </div>

                    <div class="form-buttons">
                        <button type="submit" class="btn btn-primary btn-submit">Change Password</button>
                    </div>
                </form>
            </div>

            <!-- API Information -->
            <div class="settings-container" style="margin-top: 30px;">
                <h2>API Information</h2>

                <div class="info-box">
                    <p><strong>Vote Endpoint:</strong></p>
                    <code style="display: block; margin-top: 5px; word-break: break-all; font-size: 12px;">
                        POST /src/api/vote.php
                    </code>

                    <p style="margin-top: 15px;"><strong>Data Endpoint:</strong></p>
                    <code style="display: block; margin-top: 5px; word-break: break-all; font-size: 12px;">
                        GET /src/api/data.php?widget_id=1
                    </code>

                    <p style="margin-top: 15px;"><strong>Widget Embed:</strong></p>
                    <code style="display: block; margin-top: 5px; word-break: break-all; font-size: 12px;">
                        &lt;script src="https://yourdomain.com/public/widget/embed.js" data-widget-id="1"&gt;&lt;/script&gt;
                    </code>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
