/**
 * Widget Embed Script
 * This script initializes the voting widget when embedded on external sites
 * Usage: <script src="https://yourdomain.com/widget/embed.js" data-widget-id="1" data-theme="light"></script>
 */

(function () {
  "use strict";

  /**
   * Get query parameter from script src
   */
  function getScriptParams() {
    const script =
      document.currentScript ||
      document.querySelector("script[data-widget-id]");
    if (!script) return {};

    return {
      widgetId: script.getAttribute("data-widget-id") || "1",
      theme: script.getAttribute("data-theme") || "light",
      maxRestaurants:
        parseInt(script.getAttribute("data-max-restaurants")) || 5,
      showVoteCount: script.getAttribute("data-show-vote-count") !== "false",
      apiBaseUrl: script.getAttribute("data-api-url") || getBaseUrl(),
    };
  }

  /**
   * Determine base API URL
   */
  function getBaseUrl() {
    const currentUrl = window.location.origin;
    // If on localhost, assume local setup
    if (currentUrl.includes("localhost") || currentUrl.includes("127.0.0.1")) {
      return currentUrl;
    }
    // Otherwise, use current domain
    return currentUrl;
  }

  /**
   * Load external CSS
   */
  function loadCSS(url) {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = url;
    document.head.appendChild(link);
  }

  /**
   * Load external script
   */
  function loadScript(url, callback) {
    const script = document.createElement("script");
    script.src = url;
    script.async = true;
    script.onload = callback;
    script.onerror = () => {
      console.error("Failed to load script: " + url);
    };
    document.body.appendChild(script);
  }

  /**
   * Initialize widget
   */
  function initializeWidget() {
    const params = getScriptParams();
    const baseUrl = params.apiBaseUrl;

    // Determine script directory from current script
    const currentScript =
      document.currentScript ||
      document.querySelector("script[data-widget-id]");
    const scriptDir = currentScript.src.substring(
      0,
      currentScript.src.lastIndexOf("/")
    );

    // Load CSS
    loadCSS(`${scriptDir}/widget.css`);

    // Load main widget script
    loadScript(`${scriptDir}/widget.js`, function () {
      // Create widget container if not exists
      if (!document.querySelector(".voting-widget")) {
        const container = document.createElement("div");
        container.className = "voting-widget-container";
        currentScript.parentNode.insertBefore(container, currentScript);
      }

      // Initialize widget
      const widgetContainer =
        document.querySelector(".voting-widget-container") || document.body;
      const selector = ".voting-widget-container";

      new VotingWidget({
        widgetId: parseInt(params.widgetId),
        theme: params.theme,
        maxRestaurants: params.maxRestaurants,
        showVoteCount: params.showVoteCount,
        apiBaseUrl: baseUrl,
        containerSelector: selector,
      });

      // Make widget globally accessible
      window[`votingWidget_${params.widgetId}`] = new VotingWidget({
        widgetId: parseInt(params.widgetId),
        theme: params.theme,
        maxRestaurants: params.maxRestaurants,
        showVoteCount: params.showVoteCount,
        apiBaseUrl: baseUrl,
        containerSelector: selector,
      });
    });
  }

  // Initialize when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializeWidget);
  } else {
    initializeWidget();
  }
})();
