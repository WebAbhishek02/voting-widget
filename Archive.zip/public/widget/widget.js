/**
 * Voting Widget - JavaScript Core
 * Handles carousel, voting, and real-time updates
 */

(function () {
  "use strict";

  class VotingWidget {
    constructor(config) {
      this.config = {
        apiBaseUrl: config.apiBaseUrl || "http://localhost/voting-widget",
        widgetId: config.widgetId || 1,
        containerSelector: config.containerSelector || ".voting-widget",
        theme: config.theme || "light",
        maxRestaurants: config.maxRestaurants || 5,
        showVoteCount: config.showVoteCount !== false,
        ...config,
      };

      this.restaurants = [];
      this.currentIndex = 0;
      this.votedRestaurants = new Set();
      this.isLoading = false;
      this.container = null;

      this.init();
    }

    /**
     * Initialize the widget
     */
    async init() {
      this.container = document.querySelector(this.config.containerSelector);
      if (!this.container) {
        console.error("Widget container not found");
        return;
      }

      this.loadVotedRestaurants();
      await this.fetchRestaurants();
      this.render();
      this.attachEventListeners();
    }

    /**
     * Fetch restaurants data from API
     */
    async fetchRestaurants() {
      this.isLoading = true;
      this.renderLoading();

      try {
        const response = await fetch(
          `${this.config.apiBaseUrl}/src/api/data.php?widget_id=${this.config.widgetId}`
        );

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data.success) {
          this.restaurants = data.restaurants || [];
          this.config.theme = data.widget.theme || this.config.theme;
          this.config.showVoteCount = data.widget.show_vote_count;
        } else {
          this.showFeedback("Failed to load restaurants", "error");
        }
      } catch (error) {
        console.error("Error fetching restaurants:", error);
        this.showFeedback("Failed to load restaurants", "error");
      } finally {
        this.isLoading = false;
      }
    }

    /**
     * Load voted restaurants from localStorage
     */
    loadVotedRestaurants() {
      const key = `voted_widget_${this.config.widgetId}`;
      const voted = localStorage.getItem(key);
      if (voted) {
        this.votedRestaurants = new Set(JSON.parse(voted));
      }
    }

    /**
     * Save voted restaurants to localStorage
     */
    saveVotedRestaurants() {
      const key = `voted_widget_${this.config.widgetId}`;
      localStorage.setItem(key, JSON.stringify([...this.votedRestaurants]));
    }

    /**
     * Record a vote
     */
    async vote(restaurantId) {
      if (this.votedRestaurants.has(restaurantId)) {
        this.showFeedback(
          "You have already voted for this restaurant",
          "error"
        );
        return;
      }

      const button = document.querySelector(
        `[data-restaurant-id="${restaurantId}"] .vote-button`
      );
      if (!button) return;

      button.classList.add("voting");
      button.disabled = true;

      try {
        const response = await fetch(
          `${this.config.apiBaseUrl}/src/api/vote.php`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              widget_id: this.config.widgetId,
              restaurant_id: restaurantId,
            }),
          }
        );

        const data = await response.json();

        if (response.ok && data.success) {
          this.votedRestaurants.add(restaurantId);
          this.saveVotedRestaurants();

          // Update restaurants data
          if (data.restaurants) {
            this.restaurants = data.restaurants;
          }

          this.updateRestaurantCard(restaurantId);
          this.showFeedback("Thank you for voting!", "success");
        } else {
          this.showFeedback(data.error || "Vote failed", "error");
        }
      } catch (error) {
        console.error("Error voting:", error);
        this.showFeedback("Error recording vote", "error");
      } finally {
        button.classList.remove("voting");
        button.disabled = false;
      }
    }

    /**
     * Update individual restaurant card after vote
     */
    updateRestaurantCard(restaurantId) {
      const restaurant = this.restaurants.find((r) => r.id === restaurantId);
      if (!restaurant) return;

      const card = document.querySelector(
        `[data-restaurant-id="${restaurantId}"]`
      );
      if (!card) return;

      // Update vote count
      const voteCount = card.querySelector(".vote-count");
      if (voteCount) {
        voteCount.textContent = restaurant.vote_count;
      }

      // Update percentage
      const percentage = card.querySelector(".vote-percentage");
      if (percentage) {
        percentage.textContent = `${restaurant.percentage}%`;
      }

      // Update progress bar
      const progressBar = card.querySelector(".vote-progress-bar");
      if (progressBar) {
        progressBar.style.width = `${restaurant.percentage}%`;
      }

      // Update button
      const button = card.querySelector(".vote-button");
      if (button) {
        button.classList.add("voted");
        button.textContent = "Voted ✓";
        button.disabled = true;
      }
    }

    /**
     * Render the widget
     */
    render() {
      const html = `
        <div class="voting-widget ${this.config.theme}-theme">
          <div class="widget-header">
            <h1>Vote for Your Favorite Restaurant</h1>
            <p>Help us find the best dining spots</p>
          </div>

          ${
            this.restaurants.length > 0
              ? `
            <div class="carousel-container">
              <div class="carousel-wrapper" style="transform: translateX(${
                -this.currentIndex * (100 + 1.5)
              }%)">
                ${this.restaurants
                  .map((restaurant) => this.renderCard(restaurant))
                  .join("")}
              </div>
            </div>

            ${
              this.restaurants.length > 1
                ? `
              <div class="carousel-controls">
                <button class="carousel-button prev-btn" aria-label="Previous restaurant">❮</button>
                <button class="carousel-button next-btn" aria-label="Next restaurant">❯</button>
              </div>
              <div class="carousel-indicators">
                ${this.restaurants
                  .map(
                    (_, index) => `
                  <div class="indicator-dot ${
                    index === 0 ? "active" : ""
                  }" data-index="${index}"></div>
                `
                  )
                  .join("")}
              </div>
            `
                : ""
            }
          `
              : `
            <div class="widget-loading">
              <p>No restaurants available</p>
            </div>
          `
          }
        </div>
      `;

      this.container.innerHTML = html;
    }

    /**
     * Render loading state
     */
    renderLoading() {
      const html = `
        <div class="voting-widget ${this.config.theme}-theme">
          <div class="widget-loading">
            <div class="loader"></div>
            <p style="margin-top: 15px;">Loading restaurants...</p>
          </div>
        </div>
      `;

      this.container.innerHTML = html;
    }

    /**
     * Render single restaurant card
     */
    renderCard(restaurant) {
      const isVoted = this.votedRestaurants.has(restaurant.id);
      const totalVotes = this.restaurants.reduce(
        (sum, r) => sum + r.vote_count,
        0
      );

      return `
        <div class="restaurant-card" data-restaurant-id="${restaurant.id}">
          ${
            restaurant.image_url
              ? `
            <img src="${this.sanitizeUrl(
              restaurant.image_url
            )}" alt="${this.sanitize(
                  restaurant.name
                )}" class="restaurant-image">
          `
              : `
            <div class="restaurant-image" style="display: flex; align-items: center; justify-content: center; color: #999;">
              No image
            </div>
          `
          }
          <div class="restaurant-content">
            <h3 class="restaurant-name">${this.sanitize(restaurant.name)}</h3>

            ${
              restaurant.external_link
                ? `
              <a href="${this.sanitizeUrl(
                restaurant.external_link
              )}" target="_blank" rel="noopener noreferrer" class="external-link">
                Visit Website →
              </a>
            `
                : ""
            }

            <div class="restaurant-stats">
              <div class="vote-count">${restaurant.vote_count} votes</div>
              <div class="vote-percentage">${restaurant.percentage}%</div>
            </div>

            <div class="vote-progress">
              <div class="vote-progress-bar" style="width: ${
                restaurant.percentage
              }%"></div>
            </div>

            <button class="vote-button ${isVoted ? "voted" : ""}" ${
        isVoted ? "disabled" : ""
      } onclick="window.votingWidget_${this.config.widgetId}?.vote(${
        restaurant.id
      })">
              ${isVoted ? "Voted ✓" : "Vote"}
            </button>
          </div>
        </div>
      `;
    }

    /**
     * Attach event listeners
     */
    attachEventListeners() {
      if (this.restaurants.length <= 1) return;

      const prevBtn = this.container.querySelector(".prev-btn");
      const nextBtn = this.container.querySelector(".next-btn");
      const indicators = this.container.querySelectorAll(".indicator-dot");

      if (prevBtn) prevBtn.addEventListener("click", () => this.prevSlide());
      if (nextBtn) nextBtn.addEventListener("click", () => this.nextSlide());

      indicators.forEach((indicator) => {
        indicator.addEventListener("click", (e) => {
          this.goToSlide(parseInt(e.target.dataset.index));
        });
      });

      // Keyboard navigation
      document.addEventListener("keydown", (e) => {
        if (e.key === "ArrowLeft") this.prevSlide();
        if (e.key === "ArrowRight") this.nextSlide();
      });
    }

    /**
     * Navigate to next slide
     */
    nextSlide() {
      if (this.currentIndex < this.restaurants.length - 1) {
        this.currentIndex++;
        this.updateCarousel();
      }
    }

    /**
     * Navigate to previous slide
     */
    prevSlide() {
      if (this.currentIndex > 0) {
        this.currentIndex--;
        this.updateCarousel();
      }
    }

    /**
     * Go to specific slide
     */
    goToSlide(index) {
      if (index >= 0 && index < this.restaurants.length) {
        this.currentIndex = index;
        this.updateCarousel();
      }
    }

    /**
     * Update carousel position and indicators
     */
    updateCarousel() {
      const wrapper = this.container.querySelector(".carousel-wrapper");
      if (wrapper) {
        wrapper.style.transform = `translateX(${
          -this.currentIndex * (100 + 1.5)
        }%)`;
      }

      const indicators = this.container.querySelectorAll(".indicator-dot");
      indicators.forEach((dot, index) => {
        dot.classList.toggle("active", index === this.currentIndex);
      });

      // Update button states
      const prevBtn = this.container.querySelector(".prev-btn");
      const nextBtn = this.container.querySelector(".next-btn");
      if (prevBtn) prevBtn.disabled = this.currentIndex === 0;
      if (nextBtn)
        nextBtn.disabled = this.currentIndex === this.restaurants.length - 1;
    }

    /**
     * Show feedback message
     */
    showFeedback(message, type = "success") {
      const feedback = document.createElement("div");
      feedback.className = `feedback-message ${type}`;
      feedback.textContent = message;

      document.body.appendChild(feedback);

      setTimeout(() => {
        feedback.remove();
      }, 3000);
    }

    /**
     * Sanitize HTML content
     */
    sanitize(text) {
      const div = document.createElement("div");
      div.textContent = text;
      return div.innerHTML;
    }

    /**
     * Sanitize URL
     */
    sanitizeUrl(url) {
      try {
        const parsed = new URL(url);
        if (/^https?:$/.test(parsed.protocol)) {
          return url;
        }
      } catch (e) {
        //
      }
      return "#";
    }
  }

  // Global widget initialization
  window.VotingWidget = VotingWidget;
})();
