# Voting Widget - Production Ready

A fully functional, deployment-ready embedded voting widget for restaurants built with PHP 8+, MySQL, HTML, CSS, and Vanilla JavaScript. No frameworks. Production-grade security and code quality.

## Features

### Frontend Widget

- **Responsive Carousel**: Smooth carousel navigation on desktop, tablet, and mobile
- **Real-time Voting**: Instant vote recording with visual feedback
- **Vote Tracking**: Show vote counts and percentages with progress bars
- **Duplicate Prevention**: Browser localStorage + server-side validation
- **Embeddable**: Drop into any website with a single script tag
- **Theme Support**: Light and dark theme options

### Admin Backend

- **Secure Authentication**: Session-based login with bcrypt password hashing
- **Restaurant Management**: Add, edit, delete, reorder, and toggle visibility
- **Vote Management**: View statistics, reset votes, enable/disable voting
- **Multi-widget Support**: Create and manage multiple widgets
- **Image Upload**: Secure file upload with validation
- **Dashboard**: Overview of all statistics

### Security

- PDO prepared statements (SQL injection prevention)
- CSRF token validation
- XSS protection with HTML escaping
- Secure password hashing (bcrypt)
- Session-based authentication
- Rate limiting on votes
- Server-side vote validation
- Secure file upload validation

## Project Structure

```
voting-widget/
├── database/
│   └── schema.sql              # MySQL database schema
├── public/
│   ├── index.html              # Demo page
│   ├── uploads/                # Restaurant images (must be writable)
│   ├── widget/
│   │   ├── widget.js           # Core widget JavaScript
│   │   ├── widget.css          # Widget styles
│   │   └── embed.js            # Embedding script
│   └── admin/
│       ├── login.php           # Admin login page
│       ├── index.php           # Admin dashboard
│       ├── logout.php          # Admin logout
│       ├── restaurants.php     # Manage restaurants
│       ├── votes.php           # Manage votes
│       ├── widgets.php         # Manage widgets
│       └── settings.php        # Admin settings
├── src/
│   ├── config/
│   │   ├── database.php        # Database connection & helpers
│   │   └── security.php        # Security functions & validation
│   ├── api/
│   │   ├── vote.php            # Vote submission endpoint
│   │   └── data.php            # Widget data endpoint
│   └── admin/
│       └── auth.php            # Authentication functions
└── README.md

```

## Installation

### Requirements

- PHP 8.0+
- MySQL 5.7+
- Web server (Apache/Nginx)

### Setup Steps

1. **Database Setup**

   ```bash
   mysql -u your_user -p your_database < database/schema.sql
   ```

2. **Configure Database Connection**
   Update `src/config/database.php`:

   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'voting_widget');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   ```

3. **Set Permissions**

   ```bash
   chmod 755 public/uploads
   chmod 644 public/uploads/.htaccess
   ```

4. **Create .htaccess** (optional, for URL rewriting)

   ```apache
   RewriteEngine On
   RewriteCond %{REQUEST_FILENAME} !-f
   RewriteCond %{REQUEST_FILENAME} !-d
   ```

5. **Access Admin Panel**
   - Navigate to: `http://localhost/public/admin/login.php`
   - Default credentials:
     - Username: `admin`
     - Password: `admin123`
   - **⚠️ Change immediately in production**

## API Endpoints

### Get Widget Data

**GET** `/src/api/data.php?widget_id=1`

Response:

```json
{
  "success": true,
  "widget": {
    "id": 1,
    "theme": "light",
    "show_vote_count": 1
  },
  "restaurants": [
    {
      "id": 1,
      "name": "Restaurant Name",
      "image_url": "/public/uploads/image.jpg",
      "external_link": "https://example.com",
      "vote_count": 42,
      "percentage": 25.5
    }
  ],
  "total_votes": 165
}
```

### Submit Vote

**POST** `/src/api/vote.php`

Request:

```json
{
  "widget_id": 1,
  "restaurant_id": 5
}
```

Response:

```json
{
  "success": true,
  "message": "Vote recorded successfully",
  "restaurant": {
    "id": 5,
    "name": "Restaurant Name",
    "vote_count": 43
  },
  "total_votes": 166,
  "restaurants": [...]
}
```

## Embedding the Widget

### Method 1: Script Tag (Recommended)

```html
<script
  src="https://yourdomain.com/public/widget/embed.js"
  data-widget-id="1"
  data-theme="light"
  data-max-restaurants="5"
  data-show-vote-count="true"
></script>
```

### Embed Parameters

- `data-widget-id`: Widget ID (required)
- `data-theme`: "light" or "dark" (default: light)
- `data-max-restaurants`: Number of restaurants to show (default: 5)
- `data-show-vote-count`: Show vote counts (default: true)
- `data-api-url`: Custom API URL (default: current domain)

### Method 2: Direct HTML

```html
<div class="voting-widget-container"></div>

<link rel="stylesheet" href="https://yourdomain.com/public/widget/widget.css" />
<script src="https://yourdomain.com/public/widget/widget.js"></script>

<script>
  const widget = new VotingWidget({
    widgetId: 1,
    theme: "light",
    maxRestaurants: 5,
    showVoteCount: true,
    apiBaseUrl: "https://yourdomain.com",
    containerSelector: ".voting-widget-container",
  });
</script>
```

## Admin Panel

### Dashboard

- View total widgets, restaurants, and votes
- Quick access to all management sections

### Restaurants

- Add new restaurants with images and external links
- Edit restaurant details
- Delete restaurants
- Toggle visibility (active/inactive)
- Reorder display

### Votes

- View voting statistics per restaurant
- See vote counts and percentages
- Reset votes for individual restaurants
- Reset all votes for widget

### Widgets

- Create new widgets with custom settings
- Configure theme, max restaurants, vote display
- Enable/disable voting
- View embed code
- Delete widgets

### Settings

- Change admin password
- View API endpoints
- Account information

## Database Schema

### admins

- `id` - Primary key
- `username` - Unique username
- `email` - Email address
- `password_hash` - Bcrypt hashed password
- `created_at` - Account creation timestamp
- `last_login` - Last login timestamp
- `is_active` - Account status

### widgets

- `id` - Primary key
- `name` - Widget name
- `api_key` - Unique API key
- `admin_id` - Foreign key to admins
- `theme` - light/dark
- `max_restaurants` - Max restaurants to display
- `show_vote_count` - Display vote counts
- `voting_enabled` - Enable/disable voting
- `created_at` - Creation timestamp
- `updated_at` - Last update timestamp
- `is_active` - Widget status

### restaurants

- `id` - Primary key
- `widget_id` - Foreign key to widgets
- `name` - Restaurant name
- `image_url` - Image file path
- `external_link` - External URL
- `display_order` - Sort order
- `is_active` - Visibility status
- `created_at` - Creation timestamp
- `updated_at` - Last update timestamp

### votes

- `id` - Primary key
- `restaurant_id` - Foreign key to restaurants
- `widget_id` - Foreign key to widgets
- `voter_id` - Unique voter identifier
- `vote_timestamp` - When vote was cast
- `ip_address` - Voter IP (optional)
- `user_agent` - Browser user agent (optional)
- Unique constraint: (widget_id, restaurant_id, voter_id)

## Security Best Practices

1. **Environment Variables** (Production)

   ```php
   define('DB_HOST', getenv('DB_HOST'));
   define('DB_USER', getenv('DB_USER'));
   define('DB_PASS', getenv('DB_PASS'));
   ```

2. **.htaccess Protection**

   ```apache
   # Protect sensitive files
   <Files "*.php">
       Order Deny,Allow
       Deny from all
   </Files>
   ```

3. **HTTPS**

   - Always use HTTPS in production
   - Set secure cookies

4. **File Permissions**

   ```bash
   chmod 700 src/
   chmod 600 database/schema.sql
   chmod 755 public/uploads
   ```

5. **Change Default Credentials**

   ```php
   // Update admin password in database
   UPDATE admins SET password_hash = PASSWORD('new_secure_password') WHERE id = 1;
   ```

6. **Database Backup**
   ```bash
   mysqldump -u user -p database > backup.sql
   ```

## Deployment Checklist

- [ ] Update database credentials
- [ ] Change default admin password
- [ ] Set secure file permissions
- [ ] Enable HTTPS
- [ ] Configure security headers
- [ ] Set up database backups
- [ ] Test all functionality
- [ ] Monitor error logs
- [ ] Set up rate limiting (optional)
- [ ] Enable logging/monitoring

## Code Quality

- Clean, readable code with comments
- No frameworks or dependencies
- Modular file structure
- Prepared statements for all queries
- Input validation and sanitization
- Error handling throughout
- Responsive design
- Cross-browser compatible

## Performance Considerations

- CSS caching (5 minutes for widget)
- Efficient database queries with indexes
- Minimal JavaScript bundle
- Lazy loading images (optional)
- CDN ready

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome)

## Troubleshooting

### Database Connection Error

- Check database credentials in `src/config/database.php`
- Verify MySQL server is running
- Check database user permissions

### Image Upload Fails

- Verify `public/uploads` directory is writable
- Check file size limits (max 5MB)
- Allowed formats: JPG, PNG, GIF, WebP

### Widget Not Loading

- Check browser console for errors
- Verify widget ID is correct
- Check API endpoints are accessible
- Verify CORS settings if on different domain

### Votes Not Recording

- Check server error logs
- Verify database connection
- Test vote API endpoint directly
- Check localStorage is enabled in browser

## License

This project is provided as-is for production use.

## Support

For issues or questions, check:

1. Error logs in `/src/config/database.php` output
2. Browser developer console (F12)
3. PHP error_log
4. MySQL error logs

---

**Version**: 1.0  
**Last Updated**: 2025-12-18  
**Status**: Production Ready
