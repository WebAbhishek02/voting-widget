# 🚀 GitHub & Hostinger Deployment Guide

Complete step-by-step guide to upload your voting widget to GitHub and deploy it on Hostinger.

---

## Part 1: Upload to GitHub

### Step 1: Create GitHub Repository

1. Go to [github.com](https://github.com) and log in
2. Click **"+"** (top right) → **"New repository"**
3. Fill in details:
   - **Repository name**: `voting-widget` (or your preferred name)
   - **Description**: `Production-ready voting widget for restaurants`
   - **Visibility**: Choose **Public** or **Private**
   - **Initialize repository**: Leave unchecked (we'll push existing code)
4. Click **"Create repository"**

### Step 2: Initialize Git Locally

Open Terminal and navigate to your project:

```bash
cd /Users/abhishekmishra/Documents/Learning/test-project
```

Initialize git repository:

```bash
git init
```

Add all files:

```bash
git add .
```

Create initial commit:

```bash
git commit -m "Initial commit: Production-ready voting widget application"
```

### Step 3: Connect to GitHub

Copy the repository URL from GitHub (click green "Code" button), then run:

```bash
git remote add origin https://github.com/YOUR_USERNAME/voting-widget.git
git branch -M main
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

### Step 4: Verify on GitHub

- Go to your repository on GitHub
- Verify all files are uploaded
- You should see all folders and files

---

## Part 2: Deploy to Hostinger

### Step 1: Prepare for Deployment

Before uploading, create production configuration:

#### Create `.env` file (production):

```bash
# Database Configuration
DB_HOST=your_hostinger_database_host
DB_USER=your_database_username
DB_PASS=your_database_password
DB_NAME=your_database_name
DB_PORT=3306

# Application Settings
APP_URL=https://yourdomain.com
APP_ENV=production
APP_DEBUG=false

# Security
JWT_SECRET=your_secure_random_key_here
SESSION_COOKIE_SECURE=true
SESSION_COOKIE_HTTPONLY=true
SESSION_COOKIE_SAMESITE=Strict

# File Upload
MAX_UPLOAD_SIZE=5242880
ALLOWED_EXTENSIONS=jpg,jpeg,png,gif,webp

# Feature Flags
VOTING_ENABLED=true
```

**Save this as `.env`** (not `.env.example`)

### Step 2: Set Up Hostinger Account

1. Log in to [Hostinger.com](https://www.hostinger.com)
2. Go to **Hosting** → Your hosting plan
3. Click **"Manage"**
4. Navigate to **File Manager** or **FTP**

### Step 3: Access Hostinger via FTP

#### Option A: Using File Manager (Easiest)

1. Go to **File Manager** in Hostinger control panel
2. Navigate to **public_html** folder
3. Create folder: `voting-widget`
4. Upload files here (see Step 4)

#### Option B: Using FTP Client (Recommended)

Download and install an FTP client:

- **Mac/Linux**: Cyberduck, FileZilla
- **Windows**: FileZilla, WinSCP

**Connect with these credentials** (from Hostinger):

- **Host**: ftp.yourdomain.com (or IP from Hostinger)
- **Username**: FTP username from Hostinger
- **Password**: FTP password from Hostinger
- **Port**: 21 (or 22 for SFTP)

### Step 4: Upload Files to Hostinger

**Method A: Using Git (Best)**

Connect via SSH to Hostinger (if available):

```bash
ssh username@yourdomain.com
cd public_html
git clone https://github.com/YOUR_USERNAME/voting-widget.git
cd voting-widget
```

**Method B: Using FTP**

1. Open FTP client
2. Connect to Hostinger
3. Navigate to **public_html**
4. Drag and drop all project files and folders:
   - `/src`
   - `/public`
   - `/database`
   - All `.php` files at root
   - `.htaccess`
   - `.gitignore`
   - All `.md` files
   - **Important**: Upload `.env` (with your credentials)

**Method C: Using File Manager**

1. Download project as ZIP
2. In Hostinger File Manager → **Upload** → Select ZIP
3. Extract the ZIP file
4. Reorganize if needed

### Step 5: Create Database on Hostinger

1. In Hostinger control panel → **Databases**
2. Click **"Create Database"**
3. Enter database name, user, password
4. Click **"Create"**
5. Note the credentials

#### Import Schema

1. Go to **phpMyAdmin** (usually in control panel)
2. Select your database
3. Click **"Import"** tab
4. Upload `database/schema.sql`
5. Click **"Import"**

### Step 6: Update Configuration

#### Edit `src/config/database.php`:

1. In Hostinger File Manager or FTP, edit `src/config/database.php`
2. Update credentials:

```php
$host = 'your_hostinger_db_host';      // Usually localhost
$db = 'your_database_name';
$user = 'your_database_user';
$pass = 'your_database_password';
```

**OR** use environment variables (edit `.env` file):

```
DB_HOST=localhost
DB_USER=your_db_user
DB_PASS=your_db_password
DB_NAME=your_db_name
```

#### Update `src/config/security.php`:

Check and update:

```php
define('APP_URL', 'https://yourdomain.com');
define('UPLOAD_DIR', '/path/to/uploads/');
define('MAX_UPLOAD_SIZE', 5242880); // 5MB
```

### Step 7: Configure .htaccess

Update the `.htaccess` file for your domain:

```apache
# Redirect to HTTPS (if not already)
RewriteCond %{HTTPS} off
RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Other security rules (already configured)
```

### Step 8: Set File Permissions

Via SSH or File Manager:

```bash
# Set directory permissions
chmod 755 public/uploads
chmod 755 src
chmod 755 database

# Ensure .htaccess files are readable
chmod 644 .htaccess
chmod 644 public/uploads/.htaccess

# Ensure config files are readable only by server
chmod 600 src/config/database.php
chmod 600 src/config/security.php
```

### Step 9: Verify Installation

1. Open browser: `https://yourdomain.com/voting-widget/` (or your path)
2. You should see the landing page
3. Navigate to: `https://yourdomain.com/voting-widget/public/admin/`
4. Login with:
   - **Username**: `admin`
   - **Password**: `admin123`
5. **Change password immediately** (Settings page)

### Step 10: Test All Features

- [ ] Admin login works
- [ ] Can create widget
- [ ] Can add restaurants
- [ ] Can upload images
- [ ] Widget displays on public page
- [ ] Voting works
- [ ] Vote counts update
- [ ] Statistics display correctly

---

## Hostinger-Specific Setup

### Enable PHP Extensions

1. Go to **PHP Settings** in Hostinger
2. Ensure these extensions are enabled:
   - `php_pdo.dll` (PDO)
   - `php_gd2.dll` (Image handling)
   - `php_curl.dll` (HTTP requests)

### SSL Certificate

1. Go to **SSL Certificate** in Hostinger
2. Install free Let's Encrypt SSL
3. Enable **Auto-renewal**

### Email Configuration (Optional)

For password reset emails:

1. Create email account in Hostinger
2. Update SMTP settings in `src/config/security.php`

### Scheduled Backups

1. Go to **Backups** in Hostinger
2. Set automatic daily backups
3. Keep last 30 days of backups

### Monitor Performance

1. Go to **Monitoring** in Hostinger
2. Set up alerts for:
   - High CPU usage
   - High memory usage
   - Database issues

---

## Updating Your Application

### From GitHub

After making changes on your local machine:

```bash
git add .
git commit -m "Your commit message"
git push origin main
```

Then on Hostinger (via SSH):

```bash
cd public_html/voting-widget
git pull origin main
```

Or manually download updated files via FTP.

### Database Changes

If you modify the schema:

1. Export current database
2. Update `database/schema.sql`
3. Push to GitHub
4. Test on staging
5. Manually update on Hostinger using phpMyAdmin

---

## Security Checklist Before Going Live

- [ ] Change default admin password
- [ ] Remove `.env.example` (keep only `.env`)
- [ ] Verify SSL certificate installed
- [ ] Check database user has limited permissions
- [ ] Verify uploads directory is not executable
- [ ] Enable security headers in `.htaccess`
- [ ] Test CSRF protection
- [ ] Test rate limiting
- [ ] Verify no debug mode is enabled
- [ ] Check error logging is configured
- [ ] Review error logs for issues
- [ ] Test all API endpoints
- [ ] Verify HTTPS redirect works

---

## Troubleshooting

### GitHub Upload Issues

**Issue**: "fatal: origin already exists"

```bash
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/voting-widget.git
git push -u origin main
```

**Issue**: Large files rejected

```bash
# Update .gitignore to exclude large files
echo "uploads/*" >> .gitignore
git rm --cached uploads/*
git commit -m "Remove uploads from git"
git push
```

### Hostinger Deployment Issues

**Issue**: Database connection error

- Verify database credentials in `.env` or `src/config/database.php`
- Check database host (usually `localhost`)
- Verify database user exists and has proper permissions

**Issue**: 404 errors on all pages

- Verify all files uploaded correctly
- Check `.htaccess` is present in correct location
- Verify PHP version is 8.0+
- Check error logs: `tail -f var/log/apache2/error_log`

**Issue**: Images not uploading

- Check `public/uploads` directory permissions (755)
- Verify `.htaccess` in uploads allows file uploads
- Check PHP file upload limits in `php.ini`
- Verify file size is under 5MB

**Issue**: Votes not recording

- Check database connection
- Verify votes table exists: `SELECT * FROM votes;` in phpMyAdmin
- Check browser console for JavaScript errors
- Verify API endpoint is accessible: `https://yourdomain.com/voting-widget/src/api/vote.php`

**Issue**: Admin pages show blank

- Check PHP error logs
- Verify PHP sessions are enabled
- Check database connection
- Test database query directly in phpMyAdmin

### Performance Issues

**Slow page load:**

- Enable caching in `.htaccess`
- Optimize images
- Consider CDN for static assets
- Check database indexes are created

**High CPU usage:**

- Check for infinite loops in code
- Verify rate limiting is working
- Monitor database query performance
- Check Hostinger resource limits

---

## File Permissions Reference

```
644  - Regular files (html, css, js, config)
755  - Directories and executable scripts
600  - Sensitive files (database.php, security.php)
700  - Private directories
```

---

## After Deployment Checklist

### First Week

- [ ] Monitor error logs daily
- [ ] Test all features thoroughly
- [ ] Get feedback from users
- [ ] Check analytics/statistics
- [ ] Monitor server performance

### Monthly

- [ ] Review security logs
- [ ] Check for failed login attempts
- [ ] Update documentation
- [ ] Verify backups
- [ ] Performance optimization

### Quarterly

- [ ] Security audit
- [ ] Code review
- [ ] Database optimization
- [ ] Update to latest PHP/MySQL versions
- [ ] Test disaster recovery

---

## Support & Resources

### GitHub

- [GitHub Docs](https://docs.github.com)
- [Git Commands Cheat Sheet](https://github.github.com/training-kit/downloads/github-git-cheat-sheet.pdf)

### Hostinger

- [Hostinger Support](https://support.hostinger.com)
- [Hostinger Knowledge Base](https://www.hostinger.com/help)

### PHP & MySQL

- [PHP Official Docs](https://www.php.net/docs.php)
- [MySQL Official Docs](https://dev.mysql.com/doc/)

### SSL & Security

- [Let's Encrypt](https://letsencrypt.org)
- [Mozilla Web Security Guide](https://developer.mozilla.org/en-US/docs/Web/Security)

---

## Next Steps

1. ✅ Create GitHub repository
2. ✅ Upload files to GitHub
3. ✅ Set up Hostinger hosting
4. ✅ Create database on Hostinger
5. ✅ Upload files to Hostinger
6. ✅ Update configuration
7. ✅ Test all features
8. ✅ Monitor and maintain

**You're ready to go live! 🚀**

---

**Last Updated**: December 18, 2025
**Version**: 1.0
**Status**: Production Ready
